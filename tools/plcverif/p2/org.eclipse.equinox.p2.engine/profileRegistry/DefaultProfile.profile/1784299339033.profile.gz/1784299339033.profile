<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1784299339033'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Main\Work\CERN\plcverif\cern.plcverif.cli\releng\cern.plcverif.cli.cmdline.product\target\products\cern.plcverif.cli.cmdline.app.product\linux\gtk\x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Main\Work\CERN\plcverif\cern.plcverif.cli\releng\cern.plcverif.cli.cmdline.product\target\products\cern.plcverif.cli.cmdline.app.product\linux\gtk\x86_64'/>
  </properties>
</profile>
