<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1790305470544'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/mkabir/Desktop/mutate/tools/plcverif'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/mkabir/Desktop/mutate/tools/plcverif'/>
    <property name='eclipse.touchpoint.launcherName' value='plcverif-cli'/>
  </properties>
  <units size='166'>
    <unit id='a.jre.javase' version='25.0.0' singleton='false'>
      <provides size='270'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='25.0.0'/>
        <provided namespace='java.package' name='java.applet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.desktop' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.zip' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='java.time' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.sctp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.foreign' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.event' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.logging' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.support' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.classfile' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.chrono' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='java.math' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.geom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.swing.interop' version='0.0.0'/>
        <provided namespace='java.package' name='java.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.connect.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.prefs' version='0.0.0'/>
        <provided namespace='java.package' name='java.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='sun.misc' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.format' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.server' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.function' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.image.renderable' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.nio.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='javax.smartcardio' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.random' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.dynalink.linker.support' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.dgc' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='java.net.http' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.invoke' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.catalog' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.management' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.atomic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.color' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.javadoc.doclet' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='java.rmi.registry' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.java.accessibility.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management.jfr' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.constant' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi.request' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.ref' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.instrument' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.regex' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='java.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap.spi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.tool' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.jconsole' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.classfile.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.security.jarsigner' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='java.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='java.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.classfile.constantpool' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.temporal' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.channels' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.doctree' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.net.httpserver.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jshell.execution' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.javac' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.charset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.text.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.spec' version='0.0.0'/>
        <provided namespace='java.package' name='java.nio.file.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.tree' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.font' version='0.0.0'/>
        <provided namespace='java.package' name='java.security.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.tools.attach.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.concurrent.locks' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.nimbus' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.nio.mapmode' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.jfr.consumer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.tiff' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='sun.reflect' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.classfile.instruction' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.security.auth.module' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='java.time.zone' version='0.0.0'/>
        <provided namespace='java.package' name='netscape.javascript' version='0.0.0'/>
        <provided namespace='java.package' name='java.awt.im.spi' version='0.0.0'/>
        <provided namespace='java.package' name='java.beans.beancontext' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='java.lang.module' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.source.util' version='0.0.0'/>
        <provided namespace='java.package' name='jdk.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='java.io' version='0.0.0'/>
        <provided namespace='java.package' name='java.util.jar' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.7.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='9.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='10.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='11.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='12.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='13.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='14.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='15.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='16.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='17.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='18.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='19.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='20.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='21.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='22.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='23.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='24.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='25.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact1' version='25.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact2' version='25.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='1.8.0'/>
        <provided namespace='osgi.ee' name='JavaSE/compact3' version='25.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='bcpg' version='1.84.0' singleton='false' generation='2'>
      <update id='bcpg' range='[0.0.0,1.84.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcpg'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcpg-jdk18on'/>
        <property name='maven-version' value='1.84'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcpg' version='1.84.0'/>
        <provided namespace='osgi.bundle' name='bcpg' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.apache.bzip2' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.bcpg' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.math.ec,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.attr' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.bcpg.sig' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.gpg' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.openpgp,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.gpg.keybox' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.gpg.keybox.jcajce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.gpg.keybox' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.bcpg,org.bouncycastle.bcpg.attr,org.bouncycastle.bcpg.sig,org.bouncycastle.gpg,org.bouncycastle.openpgp.operator,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.bcpg.sig,org.bouncycastle.openpgp,org.bouncycastle.openpgp.api.exception,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.openpgp,org.bouncycastle.openpgp.api,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.exception' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp,org.bouncycastle.openpgp.api' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.jcajce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.openpgp,org.bouncycastle.openpgp.api,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.api.util' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.examples' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.jcajce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.bcpg,org.bouncycastle.math.ec,org.bouncycastle.openpgp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.crypto,org.bouncycastle.crypto.modes,org.bouncycastle.crypto.params,org.bouncycastle.openpgp,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.bcpg,org.bouncycastle.openpgp,org.bouncycastle.openpgp.operator' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='bcpg' version='1.84.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='53'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.channels' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.regex' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.asn1' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.cryptlib' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.edec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.gnu' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.nist' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.ntt' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.pkcs' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.sec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.teletrust' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x509' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x9' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.agreement' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.digests' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.ec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.encodings' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.engines' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.generators' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.io' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.modes' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.params' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.signers' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.crypto.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.io' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.spec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jcajce.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jce.provider' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.jce.spec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.math.ec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.io' range='[1.84.0,1.85.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcpg
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcpg
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcpg.source' range='[1.84.0,1.84.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcpg' version='1.84.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcpg&#xA;Bundle-Version: 1.84
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='bcprov' version='1.84.0' singleton='false' generation='2'>
      <update id='bcprov' range='[0.0.0,1.84.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcprov'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcprov-jdk18on'/>
        <property name='maven-version' value='1.84'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='178'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcprov' version='1.84.0'/>
        <provided namespace='osgi.bundle' name='bcprov' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.anssi' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cryptopro' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.gm' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.nist' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ocsp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.pkcs' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.sec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.teletrust' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ua' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto.params,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x500' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x500.style' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x500' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x500' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509.qualified' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x509.sigi' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x500' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.x9' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth,org.bouncycastle.crypto.digests,org.bouncycastle.crypto.params,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.ecjpake' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.jpake' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.kdf' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.agreement.srp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.commitments' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.constraints' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.digests' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.ec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.encodings' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.engines' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.digests,org.bouncycastle.crypto.generators,org.bouncycastle.crypto.params,org.bouncycastle.math.ec,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.examples' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.fpe' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.generators' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.hash2curve' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.hash2curve.data,org.bouncycastle.crypto.hash2curve.impl,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.hash2curve.data' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.hash2curve.impl' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.hash2curve,org.bouncycastle.crypto.hash2curve.data,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.hpke' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.io' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.modes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.kems' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.kems.mlkem' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.macs' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.digests,org.bouncycastle.crypto.modes,org.bouncycastle.crypto.paddings,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.modes.gcm' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes.gcm' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.modes.kgcm' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.crypto.paddings' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.params' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.crypto.signers.slhdsa,org.bouncycastle.crypto.util,org.bouncycastle.math.ec,org.bouncycastle.math.ec.rfc8032' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.parsers' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.prng' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.prng.drbg' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.prng,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.signers' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.crypto.macs,org.bouncycastle.math.ec,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.signers.mldsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto.digests,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.signers.slhdsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.threshold' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.tls' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.crypto.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.crypto.io,org.bouncycastle.crypto.params,org.bouncycastle.math.ec,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.i18n' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.i18n.filter' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.i18n.filter' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.iana' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.interfaces,org.bouncycastle.asn1,org.bouncycastle.asn1.bc,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.util,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.spec,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.interfaces' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.io' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.compositesignatures' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.util,org.bouncycastle.jcajce.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dh' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.interfaces,javax.crypto.spec,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.agreement,org.bouncycastle.crypto.engines,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.dstu' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.crypto.agreement,org.bouncycastle.crypto.engines,org.bouncycastle.crypto.generators,org.bouncycastle.crypto.params,org.bouncycastle.crypto.signers,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ecgost' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.agreement,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ecgost12' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cryptopro,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.agreement,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.edec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.engines,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.elgamal' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.interfaces,javax.crypto.spec,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.symmetric.util,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.gost' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.ies' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.mldsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.crypto.signers,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.mlkem' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.rsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.spec,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.slhdsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.crypto.signers,org.bouncycastle.jcajce.interfaces,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.spec,org.bouncycastle.pqc.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.asn1.x9,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.crypto.signers,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util,org.bouncycastle.jcajce.spec,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec,org.bouncycastle.math.field' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.asymmetric.x509' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.config' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto.spec,org.bouncycastle.asn1,org.bouncycastle.jcajce,org.bouncycastle.jcajce.provider.util,org.bouncycastle.jce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.digest' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.symmetric.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.drbg' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.kdf' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.kdf.hkdf' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.kdf.pbkdf2' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.kdf.scrypt' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.bc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.bcfks' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jcajce.provider.keystore.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.pkcs12' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.keystore.util,org.bouncycastle.jcajce.util,org.bouncycastle.jce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.keystore.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jcajce.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.crypto.generators,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.symmetric.util,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.symmetric.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.interfaces,javax.crypto.spec,javax.security.auth,org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.crypto.modes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.provider.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.config' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.spec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.spec,javax.security.auth,org.bouncycastle.asn1,org.bouncycastle.asn1.x509,org.bouncycastle.crypto.params,org.bouncycastle.crypto.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jcajce.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth.x500,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509,org.bouncycastle.jce.spec,org.bouncycastle.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jce.exception' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.jce.interfaces' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto.interfaces,org.bouncycastle.asn1,org.bouncycastle.jce.spec,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jce.netscape' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jce.provider' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,javax.crypto.interfaces,javax.crypto.spec,javax.security.auth.x500,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.jcajce,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util,org.bouncycastle.jce.exception,org.bouncycastle.jce.interfaces,org.bouncycastle.jce.spec,org.bouncycastle.math.ec,org.bouncycastle.util,org.bouncycastle.x509,org.bouncycastle.x509.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.jce.spec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.cryptopro,org.bouncycastle.jcajce.spec,org.bouncycastle.jce.interfaces,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.ldap' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.math' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec.endo,org.bouncycastle.math.field' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.djb' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.gm' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.custom.sec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.endo' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.rfc7748' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.rfc8032' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.math.ec.rfc7748' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.ec.tools' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.x9,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.math.field' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.math.raw' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.pqc.asn1' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.cmce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.crystals.dilithium' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.falcon' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.frodo' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.hqc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.lms' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mayo' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mldsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.mlkem' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.newhope' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.crypto.util,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.ntru' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.ntruplus' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.ntruprime' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.saber' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.slhdsa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.snova' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.sphincs' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.crypto.util,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.xmss' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto,org.bouncycastle.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.crypto.xwing' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto.mlkem' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.interfaces' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.config,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.bike' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec,org.bouncycastle.pqc.legacy.bike' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.cmce' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.cmce,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.dilithium' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.crystals.dilithium,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.falcon' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.falcon,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.frodo' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.frodo,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.hqc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.hqc,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.kyber' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto.params,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.lms' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.lms,org.bouncycastle.pqc.jcajce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.mayo' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.mayo,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.newhope' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.asymmetric.util,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.newhope,org.bouncycastle.pqc.jcajce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.ntru' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.ntru,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.ntruplus' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.ntruplus,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.ntruprime' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.ntruprime,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.picnic' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec,org.bouncycastle.pqc.legacy.picnic' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.saber' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.saber,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.snova' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.pqc.crypto.snova,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.provider.util,org.bouncycastle.pqc.jcajce.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.sphincs' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.sphincs,org.bouncycastle.pqc.jcajce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.sphincsplus' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.jcajce.interfaces,org.bouncycastle.pqc.jcajce.spec,org.bouncycastle.pqc.legacy.sphincsplus' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto,org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto.params,org.bouncycastle.jcajce.provider.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.provider.xmss' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x509,org.bouncycastle.crypto,org.bouncycastle.jcajce.provider.util,org.bouncycastle.pqc.crypto.xmss,org.bouncycastle.pqc.jcajce.interfaces' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.jcajce.spec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.pqc.crypto.lms' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.bike' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.picnic' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.rainbow' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.legacy.sphincsplus' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto,org.bouncycastle.crypto.params,org.bouncycastle.pqc.crypto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.math.ntru' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.pqc.math.ntru.parameters' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.pqc.math.ntru.parameters' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.pqc.math.ntru' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.util' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.util.encoders' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.util.io' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.util.io.pem' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.util.test' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.crypto.prng' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.x509' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth.x500,org.bouncycastle.asn1,org.bouncycastle.asn1.x509,org.bouncycastle.i18n,org.bouncycastle.jce,org.bouncycastle.util,org.bouncycastle.x509.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.x509.extension' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.x509.util' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.jce,org.bouncycastle.util,org.bouncycastle.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='bcprov' version='1.84.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='31'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.channels' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.cert' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.sql' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.concurrent' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.concurrent.atomic' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.interfaces' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.directory' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcprov
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcprov
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcprov.source' range='[1.84.0,1.84.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcprov' version='1.84.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcprov&#xA;Bundle-Version: 1.84
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='bcutil' version='1.84.0' singleton='false' generation='2'>
      <update id='bcutil' range='[0.0.0,1.84.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='bcutil'/>
        <property name='maven-groupId' value='org.bouncycastle'/>
        <property name='maven-artifactId' value='bcutil-jdk18on'/>
        <property name='maven-version' value='1.84'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='51'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='bcutil' version='1.84.0'/>
        <provided namespace='osgi.bundle' name='bcutil' version='1.84.0'/>
        <provided namespace='java.package' name='org.bouncycastle.asn1.bsi' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cmc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.crmf,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cmp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.crmf,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cms' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.tsp,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cms.ecc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.crmf' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cmp,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.pkcs,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.cryptlib' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.dvcs' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cmp,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.eac' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.edec' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.esf' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.ocsp,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ess' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.est' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.pkcs' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.gnu' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.iana' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.icao' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isara' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt.ocsp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.isismtt.x509' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x500,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.iso' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.kisa' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.microsoft' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.misc' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.mozilla' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.nsri' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.ntt' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.oiw' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.rosstandart' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.smime' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cms' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.asn1.tsp' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.asn1.cmp,org.bouncycastle.asn1.cms,org.bouncycastle.asn1.x509' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi102941' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer.its.etsi102941.basetypes,org.bouncycastle.oer.its.etsi103097,org.bouncycastle.oer.its.ieee1609dot2,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi102941.basetypes' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer.its.ieee1609dot2,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi103097' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer.its.ieee1609dot2,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.etsi103097.extension' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer,org.bouncycastle.oer.its.etsi102941,org.bouncycastle.oer.its.etsi103097,org.bouncycastle.oer.its.etsi103097.extension,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2.basetypes' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.math.ec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.ieee1609dot2dot1' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer.its.ieee1609dot2,org.bouncycastle.oer.its.ieee1609dot2.basetypes' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi102941' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi102941.basetypes' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi103097' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.etsi103097.extension' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.asn1,org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2.basetypes' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.bouncycastle.oer.its.template.ieee1609dot2dot1' version='1.84.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.oer' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='bcutil' version='1.84.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='java.package' name='java.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.math' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.security' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.text' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='java.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.bouncycastle.asn1' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.nist' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.ocsp' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.pkcs' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x500' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.asn1.x509' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.math.ec' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='[1.84.0,1.85.0)'/>
        <required namespace='java.package' name='org.bouncycastle.util.io' range='[1.84.0,1.85.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcutil
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            bcutil
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='bcutil.source' range='[1.84.0,1.84.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='bcutil' version='1.84.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: bcutil&#xA;Bundle-Version: 1.84
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.common' version='1.0.0.202606241155' singleton='false' generation='2'>
      <update id='cern.plcverif.base.common' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif EMF helper plugin'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.base'/>
        <property name='maven-artifactId' value='cern.plcverif.base.common'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.common' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.common' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.emf' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.emf.textual' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.exception' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.extension' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.formattedstring' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.logging' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.process' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.progress' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.settings' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.settings.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.settings.help' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.settings.specific' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.settings.specific.annotations' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.common.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.common' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.common
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.common.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.common' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.common&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.extensions' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.base.extensions' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif base.extensions'/>
        <property name='maven-groupId' value='cern.plcverif.base'/>
        <property name='maven-artifactId' value='cern.plcverif.base.extensions'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.extensions' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.extensions' version='1.0.0.202606241155'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.extensions' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.extensions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.extensions.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.extensions' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.extensions;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.interfaces' version='1.0.0.202606241155' singleton='false' generation='2'>
      <update id='cern.plcverif.base.interfaces' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif base.interfaces'/>
        <property name='maven-groupId' value='cern.plcverif.base'/>
        <property name='maven-artifactId' value='cern.plcverif.base.interfaces'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.interfaces' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.interfaces' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.base.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.interfaces.data' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.interfaces.data.result' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.interfaces.exceptions' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.interfaces' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.interfaces
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.interfaces.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.interfaces' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.interfaces&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.models' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.base.models' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='PLCverif expressions model'/>
        <property name='df_LT.providerName' value='CERN'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='cern.plcverif.base'/>
        <property name='maven-artifactId' value='cern.plcverif.base.models'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='29'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.models' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.builder' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfabase' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfabase.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfabase.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfadeclaration' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfadeclaration.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfadeclaration.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfainstance' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfainstance.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.cfainstance.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.serialization' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.textual' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.trace' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.transformation' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.transformation.assertion' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.utils' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.validation' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.cfa.visualization' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.expr' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.expr.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.expr.string' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.expr.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.expr.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.models' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.xtextdocs.xcore' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.mwe2.launch' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.mwe2.lib' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore.xtext' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='cern.plcverif.xtextdocs.common' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.apache.log4j' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.apache.commons.logging' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='slf4j.api' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.models
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.models' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.models;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.models.exprparser' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.base.models.exprparser' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='cern.plcverif.base.models.exprparser'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.base.models.exprparser'/>
        <property name='maven-artifactId' value='cern.plcverif.base.models.exprparser'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models.exprparser' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.models.exprparser' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.exprLang' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.exprLang.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.exprLang.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.generator' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.parser.antlr' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.parser.antlr.internal' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.parser.antlr.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.scoping' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.serializer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.services' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.models.exprparser.validation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.models.exprparser' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.37.0'/>
        <required namespace='osgi.bundle' name='org.antlr.runtime' range='[3.2.0,3.2.1)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.37.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.xtextdocs.xtext' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.models.exprparser
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models.exprparser.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.models.exprparser' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.models.exprparser; singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.base.platform' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.base.platform' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif base.platform'/>
        <property name='maven-groupId' value='cern.plcverif.base'/>
        <property name='maven-artifactId' value='cern.plcverif.base.platform'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.platform' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.base.platform' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.base.platform' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.base.platform.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.base.platform' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.base.platform
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.platform.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.base.platform' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.base.platform;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.cli.cmdline' version='1.0.0.202607171441' generation='2'>
      <update id='cern.plcverif.cli.cmdline' range='[0.0.0,1.0.0.202607171441)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Command line interface for PLCverif'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.cli'/>
        <property name='maven-artifactId' value='cern.plcverif.cli.cmdline'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline' version='1.0.0.202607171441'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.cli.cmdline' version='1.0.0.202607171441'/>
        <provided namespace='java.package' name='cern.plcverif.cli.cmdline' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.cli.cmdline' version='1.0.0.202607171441'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.platform' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.inject' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.cli.cmdline
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.source' range='[1.0.0.202607171441,1.0.0.202607171441]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.cli.cmdline' version='1.0.0.202607171441'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.cli.cmdline;singleton:=true&#xA;Bundle-Version: 1.0.0.202607171441
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.cli.cmdline.app' version='1.0.0.202607171441' generation='2'>
      <update id='cern.plcverif.cli.cmdline.app' range='[0.0.0,1.0.0.202607171441)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='cli cmdline App'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.cli'/>
        <property name='maven-artifactId' value='cern.plcverif.cli.cmdline.app'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app' version='1.0.0.202607171441'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.cli.cmdline.app' version='1.0.0.202607171441'/>
        <provided namespace='osgi.identity' name='cern.plcverif.cli.cmdline.app' version='1.0.0.202607171441'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.cli.cmdline' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.cli.cmdline.app
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.source' range='[1.0.0.202607171441,1.0.0.202607171441]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.cli.cmdline.app' version='1.0.0.202607171441'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.cli.cmdline.app;singleton:=true&#xA;Bundle-Version: 1.0.0.202607171441
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.cli.cmdline.app.product' version='1.0.0.202607171441'>
      <update id='cern.plcverif.cli.cmdline.app.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif CMDLINE app'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product' version='1.0.0.202607171441'/>
      </provides>
      <requires size='109'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' range='[33.6.0.jre,33.6.0.jre]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.extensions' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug' range='[3.26.0.v20260418-1439,3.26.0.v20260418-1439]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.5.800.v20260304-1232,1.5.800.v20260304-1232]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ide' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.9.600.v20260514-2026,3.9.600.v20260514-2026]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.6.v20201214,2.3.6.v20201214]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.cfa' range='[1.0.0.202606241159,1.0.0.202606241159]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.7.300.v20250518-0609,1.7.300.v20250518-0609]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.14.700.v20260326-1107,3.14.700.v20260326-1107]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.3.700.v20260306-0556,2.3.700.v20260306-0556]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' range='[2.40.0.v20251210-1145,2.40.0.v20251210-1145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.12.100.v20251111-0704,3.12.100.v20251111-0704]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.common.types' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.job' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.9.800.v20251105-1620,3.9.800.v20251105-1620]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.interfaces' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.pattern' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='[78.3.0,78.3.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.11.400.v20251107-0507,1.11.400.v20251107-0507]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.nusmv' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.12.600.v20250906-0651,3.12.600.v20250906-0651]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.7.400.v20250516-0916,3.7.400.v20250516-0916]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' range='[1.4.800.v20250922-0444,1.4.800.v20250922-0444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.24.0.v20260518-1150,3.24.0.v20260518-1150]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.theta' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.12.300.v20250707-1221,3.12.300.v20250707-1221]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7' range='[1.0.0.202606241159,1.0.0.202606241159]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.23.300.v20260513-0740,3.23.300.v20260513-0740]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' range='[3.46.0.v20260520-1003,3.46.0.v20260520-1003]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.interfaces' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='[2.42.0.v20251210-1145,2.42.0.v20251210-1145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.5.700.v20251111-1031,1.5.700.v20251111-1031]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.3.700.v20250715-0459,1.3.700.v20250715-0459]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.esbmc' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.9.700.v20260516-0947,2.9.700.v20260516-0947]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder.standalone' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore' range='[2.46.0.v20260311-1301,2.46.0.v20260311-1301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.job' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.15.800.v20260325-1353,3.15.800.v20260325-1353]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.24.200.v20260515-1403,3.24.200.v20260515-1403]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='[2.45.0.v20260311-1301,2.45.0.v20260311-1301]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.extensions' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.xml.bind-api' range='[4.0.5,4.0.5]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.3.700.v20260304-1232,1.3.700.v20260304-1232]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' range='[2.17.0.v20250910-1205,2.17.0.v20250910-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.html' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reduction.basic' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.6.800.v20260427-0433,3.6.800.v20260427-0433]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm' range='[9.9.1,9.9.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.2.0,1.2.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.assertion' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.support.codegen' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.configuration' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.6.900.v20260512-1529,2.6.900.v20260512-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.datatypes' range='[1.0.0.202606241159,1.0.0.202606241159]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.classgraph.classgraph' range='[4.8.184,4.8.184]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' range='[1.6.800.v20260304-1232,1.6.800.v20260304-1232]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.9.700.v20260316-0549,2.9.700.v20260316-0549]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.platform' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching' range='[3.24.200.v20260408-0443,3.24.200.v20260408-0443]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen' range='[2.28.0.v20251210-1145,2.28.0.v20251210-1145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.common' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.20.400.v20260512-1534,3.20.400.v20260512-1534]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.fret' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.12.500.v20251103-0733,3.12.500.v20251103-0733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.runtime' range='[2.26.0.v20260523-1243,2.26.0.v20260523-1243]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' range='[1.5.700.v20250720-1526,1.5.700.v20250720-1526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib.macro' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.6.v20201214,2.3.6.v20201214]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.7.600.v20251211-1038,1.7.600.v20251211-1038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.summary' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.application' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.extension' range='[1.0.0.202606241159,1.0.0.202606241159]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.plaintext' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.extensions' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.4.700.v20250622-1644,1.4.700.v20250622-1644]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' range='[1.2.26,1.2.26]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.3.600.v20260306-0554,2.3.600.v20260306-0554]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.4.600.v20250722-0413,2.4.600.v20250722-0413]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.3.400.v20250515-0513,1.3.400.v20250515-0513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.inject' range='[7.0.0,7.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.34.200.v20251220-0953,3.34.200.v20251220-0953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.base.models.exprparser' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.jobmock' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind.jaxb-osgi' range='[4.0.8,4.0.8]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ecore' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.13.300.v20260108-1444,2.13.300.v20260108-1444]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' range='[1.12.0,1.12.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.cbmc' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.11.100.v20260512-1529,2.11.100.v20260512-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.summaryreporter.junit' range='[1.0.0.202606241155,1.0.0.202606241155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.lib' range='[1.7.1.v20250910-1205,1.7.1.v20250910-1205]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.9.700.v20260512-1529,1.9.700.v20260512-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' range='[1.5.800.v20251111-0852,1.5.800.v20251111-0852]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.2.18,2.2.18]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.5.900.v20260319-1254,1.5.900.v20260319-1254]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/plcverif-cli.exe);removeJvmArg(jvmArg:-XX:CompileCommand=exclude org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer::getExtendedRange);addJvmArg(jvmArg:-XX:CompileCommand=quiet);addJvmArg(jvmArg:-XX:CompileCommand=exclude org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer::getExtendedRange);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441'/>
        <provided namespace='toolingcern.plcverif.cli.cmdline.app.product' name='cern.plcverif.cli.cmdline.app.product.executable' version='1.0.0.202607171441'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64.plcverif-cli' version='1.0.0.202607171441' singleton='false'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64.plcverif-cli' version='1.0.0.202607171441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setLauncherName(name:plcverif-cli)
          </instruction>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.backend.cbmc' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.backend.cbmc' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.backend.cbmc'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.backend.cbmc'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.cbmc' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.backend.cbmc' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.cbmc' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.cbmc.model' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.backend.cbmc' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.support.codegen' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.backend.cbmc
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.cbmc.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.backend.cbmc' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.backend.cbmc;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.backend.esbmc' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.backend.esbmc' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Esbmc'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.backend.esbmc'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.esbmc' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.backend.esbmc' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.esbmc' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.esbmc.model' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.backend.esbmc' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.support.codegen' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.backend.esbmc
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.esbmc.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.backend.esbmc' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.backend.esbmc;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.backend.nusmv' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.backend.nusmv' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.backend.nusmv'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.backend.nusmv'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.nusmv' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.backend.nusmv' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.nusmv' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.backend.nusmv' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.backend.nusmv
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.nusmv.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.backend.nusmv' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.backend.nusmv;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.backend.theta' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.backend.theta' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.backend.theta'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.backend.theta'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.theta' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.backend.theta' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.theta' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.backend.theta.model' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.backend.theta' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.backend.theta
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.backend.theta.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.backend.theta' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.backend.theta;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.reduction.basic' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.reduction.basic' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.reduction.basic'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.reduction.basic'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reduction.basic' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.reduction.basic' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.reduction.basic' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.reduction.basic' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.reduction.basic
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reduction.basic.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.reduction.basic' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.reduction.basic;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.reporter.html' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.reporter.html' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.reporter.html'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.reporter.html'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.html' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.reporter.html' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.html.common' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.html.individual' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.html.summary' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.html.summary.impl' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.reporter.html' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.summary.extensions' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.reporter.html
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.html.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.reporter.html' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.reporter.html;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.reporter.plaintext' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.reporter.plaintext' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.reporter.plaintext'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.reporter.plaintext'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.plaintext' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.reporter.plaintext' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.plaintext' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='cern.plcverif.base.common.settings.help,cern.plcverif.verif.interfaces.data,cern.plcverif.verif.interfaces,cern.plcverif.base.common.settings' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='cern.plcverif.library.reporter.plaintext' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.reporter.plaintext
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.plaintext.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.reporter.plaintext' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.reporter.plaintext;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.reporter.summary' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.reporter.summary' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.reporter.summary'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.reporter.summary'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.summary' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.reporter.summary' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.reporter.summary' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.reporter.summary' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.summary.extensions' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.reporter.summary
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.reporter.summary.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.reporter.summary' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.reporter.summary;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.requirement.assertion' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.requirement.assertion' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.requirement.assertion'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.requirement.assertion'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.assertion' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.requirement.assertion' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.assertion' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.requirement.assertion' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.requirement.assertion
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.assertion.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.requirement.assertion' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.requirement.assertion;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.requirement.fret' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.requirement.fret' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif fret requirements'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.requirement.fret'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.fret' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.requirement.fret' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.fret' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.fret.exceptions' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.requirement.fret' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models.exprparser' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='jakarta.xml.bind-api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.requirement.fret
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.fret.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.requirement.fret' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.requirement.fret;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.requirement.pattern' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.requirement.pattern' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif pattern-based requirement'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.requirement.pattern'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.pattern' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.requirement.pattern' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.pattern' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.pattern.configuration' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.pattern.configuration.jaxb' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.library.requirement.pattern.exceptions' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.requirement.pattern' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models.exprparser' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='jakarta.xml.bind-api' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.sun.xml.bind.jaxb-osgi' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.requirement.pattern
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.requirement.pattern.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.requirement.pattern' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.requirement.pattern;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.library.summaryreporter.junit' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.library.summaryreporter.junit' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif library.summaryreporter.junit'/>
        <property name='maven-groupId' value='cern.plcverif.library'/>
        <property name='maven-artifactId' value='cern.plcverif.library.summaryreporter.junit'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.summaryreporter.junit' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.library.summaryreporter.junit' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.library.summaryreporter.junit' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.library.summaryreporter.junit' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.summary.extensions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.library.summaryreporter.junit
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.library.summaryreporter.junit.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.library.summaryreporter.junit' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.library.summaryreporter.junit;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.plc.step7' version='1.0.0.202606241159' generation='2'>
      <update id='cern.plcverif.plc.step7' range='[0.0.0,1.0.0.202606241159)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='cern.plcverif.plc.step7'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.plc.step7'/>
        <property name='maven-artifactId' value='cern.plcverif.plc.step7'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7' version='1.0.0.202606241159'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.plc.step7' version='1.0.0.202606241159'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.formatting2' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.generator' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.indexing' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.parser.antlr' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.parser.antlr.internal' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.parser.antlr.lexer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.scoping' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.serializer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.services' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.step7Language' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.step7Language.impl' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.step7Language.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.symboltable' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.transformation' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.typecomputer' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.util' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.validation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.plc.step7' version='1.0.0.202606241159'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.37.0'/>
        <required namespace='osgi.bundle' name='org.antlr.runtime' range='[3.2.0,3.2.1)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.util' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.37.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.plc.step7.datatypes' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.xtextdocs.xtext' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <required namespace='java.package' name='org.junit' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.log4j' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.plc.step7
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.source' range='[1.0.0.202606241159,1.0.0.202606241159]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.plc.step7' version='1.0.0.202606241159'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.plc.step7; singleton:=true&#xA;Bundle-Version: 1.0.0.202606241159
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.plc.step7.cfa' version='1.0.0.202606241159' singleton='false' generation='2'>
      <update id='cern.plcverif.plc.step7.cfa' range='[0.0.0,1.0.0.202606241159)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='STEP 7 PLC programs to CFA'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.plc.step7'/>
        <property name='maven-artifactId' value='cern.plcverif.plc.step7.cfa'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.cfa' version='1.0.0.202606241159'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.plc.step7.cfa' version='1.0.0.202606241159'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.cfa' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.cfa.exceptions' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.cfa.impl' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.plc.step7.cfa' version='1.0.0.202606241159'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.plc.step7' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.plc.step7.datatypes' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.plc.step7.cfa
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.cfa.source' range='[1.0.0.202606241159,1.0.0.202606241159]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.plc.step7.cfa' version='1.0.0.202606241159'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.plc.step7.cfa&#xA;Bundle-Version: 1.0.0.202606241159
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.plc.step7.datatypes' version='1.0.0.202606241159' generation='2'>
      <update id='cern.plcverif.plc.step7.datatypes' range='[0.0.0,1.0.0.202606241159)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='STEP 7 data type metamodel'/>
        <property name='df_LT.providerName' value='CERN'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='cern.plcverif.plc.step7'/>
        <property name='maven-artifactId' value='cern.plcverif.plc.step7.datatypes'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.datatypes' version='1.0.0.202606241159'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.plc.step7.datatypes' version='1.0.0.202606241159'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.datatypes' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.datatypes.impl' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.plc.step7.datatypes' version='1.0.0.202606241159'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.plc.step7.datatypes
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.datatypes.source' range='[1.0.0.202606241159,1.0.0.202606241159]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.plc.step7.datatypes' version='1.0.0.202606241159'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.plc.step7.datatypes;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241159
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.plc.step7.extension' version='1.0.0.202606241159' generation='2'>
      <update id='cern.plcverif.plc.step7.extension' range='[0.0.0,1.0.0.202606241159)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif STEP 7 parser extension'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.plc.step7'/>
        <property name='maven-artifactId' value='cern.plcverif.plc.step7.extension'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.extension' version='1.0.0.202606241159'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.plc.step7.extension' version='1.0.0.202606241159'/>
        <provided namespace='java.package' name='cern.plcverif.plc.step7.extension' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.plc.step7.extension' version='1.0.0.202606241159'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.plc.step7' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.plc.step7.cfa' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.plc.step7.extension
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.plc.step7.extension.source' range='[1.0.0.202606241159,1.0.0.202606241159]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.plc.step7.extension' version='1.0.0.202606241159'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.plc.step7.extension;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241159
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.support.codegen' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.support.codegen' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='4'>
        <property name='maven-groupId' value='cern.plcverif.support'/>
        <property name='maven-artifactId' value='cern.plcverif.support.codegen'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.support.codegen' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.support.codegen' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.generator' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.generator.c' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.pass' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.program' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.program.statement' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.support.codegen.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.support.codegen' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.apache.logging.log4j.api' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.support.codegen
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.support.codegen.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.support.codegen' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.support.codegen;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.extensions' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.verif.extensions' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif verif.extensions'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.extensions'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.extensions' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.extensions' version='1.0.0.202606241155'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.extensions' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.extensions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.extensions.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.extensions' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.extensions;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.interfaces' version='1.0.0.202606241155' singleton='false' generation='2'>
      <update id='cern.plcverif.verif.interfaces' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif verif.interfaces'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.interfaces'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.interfaces' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.verif.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.interfaces.data' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.interfaces.data.cex' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.interfaces' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.interfaces
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.interfaces.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.interfaces' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.interfaces&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.job' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.verif.job' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif verif.job'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.job'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.job' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.job' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.verif.job' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.requirement' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.utils' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.utils.backend' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.utils.diagnoser' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.utils.requirement' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.job' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.platform' range='1.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.job
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.job.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.job' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.job;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.jobmock' version='1.0.0.202606241155' singleton='false' generation='2'>
      <update id='cern.plcverif.verif.jobmock' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif Verification job mock'/>
        <property name='org.eclipse.equinox.p2.provider' value='CERN'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.jobmock'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.jobmock' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.jobmock' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.verif.jobmock' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.jobmock' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.junit' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.library.reduction.basic' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.library.reporter.plaintext' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.library.requirement.assertion' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.models' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.library.backend.nusmv' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='1.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.jobmock
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.jobmock.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.jobmock' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.jobmock&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.summary.extensions' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.verif.summary.extensions' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif verif.summary.extensions'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.summary.extensions'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.extensions' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.summary.extensions' version='1.0.0.202606241155'/>
        <provided namespace='java.package' name='cern.plcverif.verif.summary.extensions.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.summary.extensions.interfaces.data' version='0.0.0'/>
        <provided namespace='java.package' name='cern.plcverif.verif.summary.extensions.parsernodes' version='0.0.0'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.summary.extensions' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.job' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.extensions' range='1.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.summary.extensions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.extensions.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.summary.extensions' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.summary.extensions;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='cern.plcverif.verif.summary.job' version='1.0.0.202606241155' generation='2'>
      <update id='cern.plcverif.verif.summary.job' range='[0.0.0,1.0.0.202606241155)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='PLCverif verif.summary.job'/>
        <property name='maven-groupId' value='cern.plcverif.verif'/>
        <property name='maven-artifactId' value='cern.plcverif.verif.summary.job'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.job' version='1.0.0.202606241155'/>
        <provided namespace='osgi.bundle' name='cern.plcverif.verif.summary.job' version='1.0.0.202606241155'/>
        <provided namespace='osgi.identity' name='cern.plcverif.verif.summary.job' version='1.0.0.202606241155'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.interfaces' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.base.extensions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='0.0.0'/>
        <required namespace='osgi.bundle' name='cern.plcverif.verif.summary.extensions' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=25))'>
          <description>
            cern.plcverif.verif.summary.job
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.verif.summary.job.source' range='[1.0.0.202606241155,1.0.0.202606241155]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='cern.plcverif.verif.summary.job' version='1.0.0.202606241155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: cern.plcverif.verif.summary.job;singleton:=true&#xA;Bundle-Version: 1.0.0.202606241155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.google.guava' version='33.6.0.jre' singleton='false' generation='2'>
      <update id='com.google.guava' range='[0.0.0,33.6.0.jre)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Guava: Google Core Libraries for Java'/>
        <property name='org.eclipse.equinox.p2.description' value='Guava is a suite of core and expanded libraries that include    utility classes, Google&apos;s collections, I/O classes, and    much more.'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://github.com/google/guava/'/>
        <property name='maven-groupId' value='com.google.guava'/>
        <property name='maven-artifactId' value='guava'/>
        <property name='maven-version' value='33.6.0-jre'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.google.guava' version='33.6.0.jre'/>
        <provided namespace='osgi.bundle' name='com.google.guava' version='33.6.0.jre'/>
        <provided namespace='java.package' name='com.google.common.annotations' version='33.6.0'/>
        <provided namespace='java.package' name='com.google.common.base' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.cache' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,com.google.common.collect,com.google.common.util.concurrent,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.collect' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.escape' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.eventbus' version='33.6.0'/>
        <provided namespace='java.package' name='com.google.common.graph' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.collect,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.hash' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.html' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.escape' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.io' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,com.google.common.collect,com.google.common.graph,com.google.common.hash,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.math' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.net' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,com.google.common.collect,com.google.common.escape,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.primitives' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.reflect' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.collect,com.google.common.io,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.util.concurrent' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.base,com.google.common.collect,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.google.common.xml' version='33.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.google.common.escape' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.google.guava' version='33.6.0.jre'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='com.google.common.util.concurrent.internal' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.jspecify.annotations' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.google.guava
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava.source' range='[33.6.0.jre,33.6.0.jre]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.google.guava' version='33.6.0.jre'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.google.guava&#xA;Bundle-Version: 33.6.0.jre
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.google.guava.failureaccess' version='1.0.3' singleton='false' generation='2'>
      <update id='com.google.guava.failureaccess' range='[0.0.0,1.0.3)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Guava InternalFutureFailureAccess and InternalFutures'/>
        <property name='org.eclipse.equinox.p2.description' value='Contains    com.google.common.util.concurrent.internal.InternalFutureFailureAccess and    InternalFutures. Most users will never need to use this artifact. Its    classes are conceptually a part of Guava, but they&apos;re in this separate    artifact so that Android libraries can use them without pulling in all of    Guava (just as they can use ListenableFuture by depending on the    listenablefuture artifact).'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://github.com/google/guava/'/>
        <property name='maven-groupId' value='com.google.guava'/>
        <property name='maven-artifactId' value='failureaccess'/>
        <property name='maven-version' value='1.0.3'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.google.guava.failureaccess' version='1.0.3'/>
        <provided namespace='osgi.bundle' name='com.google.guava.failureaccess' version='1.0.3'/>
        <provided namespace='java.package' name='com.google.common.util.concurrent.internal' version='1.0.3'/>
        <provided namespace='osgi.identity' name='com.google.guava.failureaccess' version='1.0.3'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.google.guava.failureaccess
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.guava.failureaccess.source' range='[1.0.3,1.0.3]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.google.guava.failureaccess' version='1.0.3'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.google.guava.failureaccess&#xA;Bundle-Version: 1.0.3
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.google.inject' version='7.0.0' singleton='false' generation='2'>
      <update id='com.google.inject' range='[0.0.0,7.0.0)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='guice'/>
        <property name='org.eclipse.equinox.p2.description' value='Guice is a lightweight dependency injection framework for Java 8 and above'/>
        <property name='org.eclipse.equinox.p2.provider' value='Google, Inc.'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://github.com/google/guice'/>
        <property name='maven-groupId' value='com.google.inject'/>
        <property name='maven-artifactId' value='guice'/>
        <property name='maven-version' value='7.0.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.google.inject' version='7.0.0'/>
        <provided namespace='osgi.bundle' name='com.google.inject' version='7.0.0'/>
        <provided namespace='java.package' name='com.google.inject' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.binder' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.matcher' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.multibindings' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.name' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.spi' version='1.4.0'/>
        <provided namespace='java.package' name='com.google.inject.util' version='1.4.0'/>
        <provided namespace='osgi.identity' name='com.google.inject' version='7.0.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='com.google.common.base' range='31.0.0'/>
        <required namespace='java.package' name='com.google.common.cache' range='31.0.0'/>
        <required namespace='java.package' name='com.google.common.collect' range='31.0.0'/>
        <required namespace='java.package' name='com.google.common.primitives' range='31.0.0'/>
        <required namespace='java.package' name='com.google.errorprone.annotations' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='jakarta.inject' range='2.0.0'/>
        <required namespace='java.package' name='org.aopalliance.intercept' range='0.0.0'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.google.inject
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.google.inject
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.google.inject.source' range='[7.0.0,7.0.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.google.inject' version='7.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.google.inject&#xA;Bundle-Version: 7.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.ibm.icu' version='78.3.0' singleton='false' generation='2'>
      <update id='com.ibm.icu' range='[0.0.0,78.3.0)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ICU4J'/>
        <property name='org.eclipse.equinox.p2.description' value='International Components for Unicode for Java'/>
        <property name='org.eclipse.equinox.p2.provider' value='Unicode, Inc.'/>
        <property name='maven-groupId' value='com.ibm.icu'/>
        <property name='maven-artifactId' value='icu4j'/>
        <property name='maven-version' value='78.3'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' version='78.3.0'/>
        <provided namespace='osgi.bundle' name='com.ibm.icu' version='78.3.0'/>
        <provided namespace='java.package' name='com.ibm.icu.lang' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.math' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.number' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.text' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='com.ibm.icu' version='78.3.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            com.ibm.icu
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu.source' range='[78.3.0,78.3.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.ibm.icu' version='78.3.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.ibm.icu&#xA;Bundle-Version: 78.3
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna' version='5.18.1.v20251001-0800' singleton='false' generation='2'>
      <update id='com.sun.jna' range='[0.0.0,5.18.1.v20251001-0800)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='jna'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='JNA Development Team'/>
        <property name='maven-wrapped-groupId' value='net.java.dev.jna'/>
        <property name='maven-wrapped-artifactId' value='jna'/>
        <property name='maven-wrapped-version' value='5.18.1'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna' version='5.18.1.v20251001-0800'/>
        <provided namespace='osgi.bundle' name='com.sun.jna' version='5.18.1.v20251001-0800'/>
        <provided namespace='java.package' name='com.sun.jna' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.ptr' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.win32' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.sun.jna' version='5.18.1.v20251001-0800'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.6))'>
          <description>
            com.sun.jna
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.source' range='[5.18.1.v20251001-0800,5.18.1.v20251001-0800]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna' version='5.18.1.v20251001-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna&#xA;Bundle-Version: 5.18.1.v20251001-0800
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.jna.platform' version='5.18.1' singleton='false' generation='2'>
      <update id='com.sun.jna.platform' range='[0.0.0,5.18.1)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='jna-platform'/>
        <property name='org.eclipse.equinox.p2.description' value='JNA Platform Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='JNA Development Team'/>
        <property name='maven-groupId' value='net.java.dev.jna'/>
        <property name='maven-artifactId' value='jna-platform'/>
        <property name='maven-version' value='5.18.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform' version='5.18.1'/>
        <provided namespace='osgi.bundle' name='com.sun.jna.platform' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.dnd' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform.linux' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.unix' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.mac' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform,com.sun.jna.platform.unix,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix.aix' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.unix.solaris' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform,com.sun.jna.platform.win32.COM,com.sun.jna.ptr,com.sun.jna.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM.util,com.sun.jna.ptr,com.sun.jna.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna.platform.win32.COM.tlb.imp' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.tlb.imp' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32,com.sun.jna.platform.win32.COM,com.sun.jna.platform.win32.COM.util.annotation,com.sun.jna.ptr' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.jna.platform.win32.COM.util.annotation' version='5.18.1'/>
        <provided namespace='java.package' name='com.sun.jna.platform.wince' version='5.18.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.jna,com.sun.jna.platform.win32' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.sun.jna.platform' version='5.18.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='com.sun.jna' range='5.18.1'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.4))'>
          <description>
            com.sun.jna.platform
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.jna.platform.source' range='[5.18.1,5.18.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.jna.platform' version='5.18.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.jna.platform&#xA;Bundle-Version: 5.18.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.sun.xml.bind.jaxb-osgi' version='4.0.8' singleton='false' generation='2'>
      <update id='com.sun.xml.bind.jaxb-osgi' range='[0.0.0,4.0.8)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='JAXB OSGI'/>
        <property name='org.eclipse.equinox.p2.description' value='JAXB OSGI bundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='com.sun.xml.bind'/>
        <property name='maven-artifactId' value='jaxb-osgi'/>
        <property name='maven-version' value='4.0.8'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='139'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind.jaxb-osgi' version='4.0.8'/>
        <provided namespace='osgi.bundle' name='com.sun.xml.bind.jaxb-osgi' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.codemodel' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.codemodel.fmt' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.codemodel.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.codemodel.writer' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.istack' version='4.1.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,javax.xml.stream,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.istack.localization' version='4.1.2'/>
        <provided namespace='java.package' name='com.sun.istack.logging' version='4.1.2'/>
        <provided namespace='java.package' name='com.sun.istack.tools' version='4.1.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.tools.ant,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.jxc.api,com.sun.tools.jxc.gen.config,jakarta.xml.bind,javax.annotation.processing,javax.lang.model.element,org.apache.tools.ant.taskdefs,org.apache.tools.ant.types,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc.ap' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,javax.annotation.processing,javax.lang.model,javax.lang.model.element,javax.lang.model.type,org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.runtime.v2.model.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc.api' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc.api,jakarta.xml.bind,javax.annotation.processing,javax.lang.model.element,javax.lang.model.type,javax.xml.namespace,javax.xml.transform' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc.api.impl.j2s' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.jxc.api,com.sun.tools.xjc.api,javax.annotation.processing,javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc.gen.config' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.jxc,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.jxc.model.nav' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.annotation.processing,javax.lang.model.element,javax.lang.model.type,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngdatatype' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.rngdatatype.helpers' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.ast.builder' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngom.ast.om,com.sun.tools.rngom.parse' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.ast.om' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.rngom.ast.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.parse,com.sun.tools.rngom.parse.host,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.binary' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.binary.visitor,com.sun.tools.rngom.nc,com.sun.tools.rngom.parse,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.binary.visitor' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.tools.rngom.binary,com.sun.tools.rngom.nc' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.digested' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.ast.util,com.sun.tools.rngom.nc,com.sun.tools.rngom.parse,javax.xml.namespace,javax.xml.stream,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.dt' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.dt.builtin' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.nc' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.parse' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.parse.compact' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.parse,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.parse.host' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.parse' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.parse.xml' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.tools.rngom.ast.builder,com.sun.tools.rngom.ast.om,com.sun.tools.rngom.parse,com.sun.tools.rngom.xml.sax,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.util' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.rngom.xml.sax' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.xml.sax,org.xml.sax.ext' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.rngom.xml.util' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.xjc' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.istack.tools,com.sun.tools.xjc.api,com.sun.tools.xjc.generator.bean.field,com.sun.tools.xjc.model,com.sun.tools.xjc.outline,com.sun.tools.xjc.reader.internalizer,com.sun.xml.xsom,com.sun.xml.xsom.parser,javax.xml.validation,org.apache.tools.ant,org.apache.tools.ant.taskdefs,org.apache.tools.ant.types,org.glassfish.jaxb.core.api.impl,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.accessors' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.at_generated' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.code_injector' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.episode' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.locator' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.addon.sync' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.outline,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.api' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,jakarta.xml.bind,javax.annotation.processing,javax.lang.model.element,javax.lang.model.type,javax.xml.namespace,javax.xml.stream,javax.xml.transform,org.glassfish.jaxb.core.api,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.api.impl.s2j' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.api,com.sun.tools.xjc.model,com.sun.tools.xjc.outline,com.sun.tools.xjc.reader.internalizer,javax.xml.namespace,javax.xml.stream,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator.annotation.ri' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,org.glassfish.jaxb.core.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator.annotation.spec' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,jakarta.xml.bind.annotation,jakarta.xml.bind.annotation.adapters' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator.bean' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.model,com.sun.tools.xjc.outline,com.sun.tools.xjc.util,jakarta.xml.bind.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator.bean.field' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc.generator.bean,com.sun.tools.xjc.model,com.sun.tools.xjc.outline' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.generator.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.model' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.api,com.sun.tools.xjc.generator.bean,com.sun.tools.xjc.generator.bean.field,com.sun.tools.xjc.model.nav,com.sun.tools.xjc.outline,com.sun.tools.xjc.reader.xmlschema.bindinfo,com.sun.xml.xsom,jakarta.activation,jakarta.xml.bind.annotation,jakarta.xml.bind.annotation.adapters,javax.xml.namespace,javax.xml.transform,org.glassfish.jaxb.core.api.impl,org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.model.nav' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc.outline,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.outline' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.generator.bean,com.sun.tools.xjc.model,com.sun.tools.xjc.util,jakarta.xml.bind.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.model,com.sun.tools.xjc.util,jakarta.activation,org.glassfish.jaxb.core.v2.model.core,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.dtd' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.model,com.sun.xml.dtdparser,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.dtd.bindinfo' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.generator.bean.field,com.sun.tools.xjc.model,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.gbind' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.internalizer' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.xml.xsom,com.sun.xml.xsom.parser,javax.xml.parsers,javax.xml.stream,javax.xml.transform.sax,javax.xml.validation,org.w3c.dom,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.relaxng' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.rngom.digested,com.sun.tools.xjc,com.sun.tools.xjc.model,com.sun.tools.xjc.reader,com.sun.tools.xjc.reader.internalizer,org.w3c.dom,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.rngom.nc,com.sun.tools.xjc,com.sun.tools.xjc.generator.bean.field,com.sun.tools.xjc.model,com.sun.tools.xjc.reader,com.sun.tools.xjc.reader.gbind,com.sun.tools.xjc.reader.xmlschema.bindinfo,com.sun.xml.xsom,com.sun.xml.xsom.visitor,jakarta.activation,javax.xml.namespace,javax.xml.transform,org.glassfish.jaxb.core.api.impl,org.glassfish.jaxb.core.v2.model.core' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.bindinfo' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.generator.bean,com.sun.tools.xjc.model,com.sun.tools.xjc.reader,com.sun.tools.xjc.reader.xmlschema,com.sun.xml.xsom,com.sun.xml.xsom.parser,jakarta.xml.bind,jakarta.xml.bind.annotation,javax.xml.namespace,javax.xml.transform.sax,org.glassfish.jaxb.core.api.impl,org.w3c.dom,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.ct' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc.reader.xmlschema,com.sun.xml.xsom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.parser' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc,com.sun.tools.xjc.reader.internalizer,org.w3c.dom,org.w3c.dom.ls,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.runtime' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,jakarta.xml.bind.annotation.adapters' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.codemodel,com.sun.tools.xjc,com.sun.tools.xjc.api,com.sun.xml.xsom,jakarta.activation,jakarta.xml.bind.annotation.adapters,javax.xml.namespace,org.w3c.dom,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.tools.xjc.writer' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.xjc.outline' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.dtdparser' version='1.5.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.dtdparser.resources' version='1.5.1'/>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset.util,com.sun.xml.fastinfoset.vocab,javax.xml.namespace,org.jvnet.fastinfoset,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.algorithm' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.jvnet.fastinfoset' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.alphabet' version='2.1.1'/>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.dom' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset,com.sun.xml.fastinfoset.util,org.jvnet.fastinfoset,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.org.apache.xerces.util' version='2.1.1'/>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.resources' version='2.1.1'/>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.sax' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset,com.sun.xml.fastinfoset.algorithm,com.sun.xml.fastinfoset.util,org.jvnet.fastinfoset,org.jvnet.fastinfoset.sax,org.xml.sax,org.xml.sax.ext' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.stax' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset,com.sun.xml.fastinfoset.sax,com.sun.xml.fastinfoset.util,javax.xml.namespace,javax.xml.stream,org.jvnet.fastinfoset,org.jvnet.fastinfoset.stax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.stax.events' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,javax.xml.stream,javax.xml.stream.events,javax.xml.stream.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.stax.factory' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,javax.xml.stream,javax.xml.stream.events,javax.xml.stream.util,javax.xml.transform' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.stax.util' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,javax.xml.stream' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.tools' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset.util,com.sun.xml.fastinfoset.vocab,javax.xml.namespace,javax.xml.stream,org.jvnet.fastinfoset,org.xml.sax,org.xml.sax.ext,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.util' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset,javax.xml.namespace,org.jvnet.fastinfoset' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.fastinfoset.vocab' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset.util,org.jvnet.fastinfoset' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.txw2' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.txw2.output,javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.txw2.annotation' version='4.0.8'/>
        <provided namespace='java.package' name='com.sun.xml.txw2.output' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.txw2,javax.xml.namespace,javax.xml.stream,javax.xml.transform,javax.xml.transform.dom,javax.xml.transform.sax,javax.xml.transform.stream,org.w3c.dom,org.xml.sax,org.xml.sax.ext,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.xml.xsom.parser,com.sun.xml.xsom.visitor,javax.xml.namespace,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.impl' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.xml.xsom,com.sun.xml.xsom.impl.parser,com.sun.xml.xsom.parser,com.sun.xml.xsom.visitor,javax.xml.namespace,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.impl.parser' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.tools.rngdatatype,com.sun.xml.xsom,com.sun.xml.xsom.impl,com.sun.xml.xsom.impl.parser.state,com.sun.xml.xsom.parser,javax.xml.parsers,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.impl.parser.state' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom.impl.parser,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.impl.scd' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom,com.sun.xml.xsom.impl,javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.impl.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom,com.sun.xml.xsom.visitor,javax.swing,javax.swing.tree,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.parser' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom,javax.xml.parsers,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom,com.sun.xml.xsom.parser,com.sun.xml.xsom.visitor' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='com.sun.xml.xsom.visitor' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.xsom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.annotation' version='4.0.8'/>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.api' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.api.impl' version='4.0.8'/>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.marshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.w3c.dom,org.xml.sax,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.unmarshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,org.glassfish.jaxb.core.v2.runtime.unmarshaller,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.util' version='4.0.8'/>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2' version='4.0.8'/>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.model.annotation' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.model.core' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,jakarta.xml.bind,jakarta.xml.bind.annotation,jakarta.xml.bind.annotation.adapters,javax.xml.namespace,javax.xml.transform,org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.core.v2.model.impl,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.model.impl' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.core.v2.model.nav' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.model.nav' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.model.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.runtime' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,jakarta.xml.bind,jakarta.xml.bind.annotation.adapters,org.glassfish.jaxb.core.v2.model.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.runtime.unmarshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.schemagen.episode' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.txw2,com.sun.xml.txw2.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.core.v2.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,javax.xml.transform,javax.xml.validation,javax.xml.xpath' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,jakarta.xml.bind.annotation.adapters,javax.xml.datatype,javax.xml.namespace,javax.xml.stream,org.glassfish.jaxb.runtime.v2.runtime.reflect,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.api' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,jakarta.xml.bind.attachment,javax.xml.namespace,javax.xml.stream,javax.xml.transform,org.glassfish.jaxb.runtime.v2.model.annotation,org.glassfish.jaxb.runtime.v2.model.runtime,org.glassfish.jaxb.runtime.v2.runtime,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.marshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.glassfish.jaxb.core.marshaller' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.unmarshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind.helpers,org.glassfish.jaxb.runtime,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.v2.model.annotation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.annotation' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.impl' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,javax.xml.namespace,org.glassfish.jaxb.core.v2.model.annotation,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.model.impl,org.glassfish.jaxb.core.v2.model.nav,org.glassfish.jaxb.core.v2.runtime,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.v2.model.annotation,org.glassfish.jaxb.runtime.v2.model.runtime,org.glassfish.jaxb.runtime.v2.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.runtime' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,javax.xml.namespace,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.reflect,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.istack,jakarta.activation,jakarta.xml.bind,jakarta.xml.bind.annotation,jakarta.xml.bind.annotation.adapters,jakarta.xml.bind.attachment,jakarta.xml.bind.helpers,javax.xml.namespace,javax.xml.parsers,javax.xml.stream,javax.xml.transform,javax.xml.transform.sax,javax.xml.validation,org.glassfish.jaxb.core.marshaller,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.runtime,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.marshaller,org.glassfish.jaxb.runtime.v2.model.annotation,org.glassfish.jaxb.runtime.v2.model.runtime,org.glassfish.jaxb.runtime.v2.runtime.output,org.glassfish.jaxb.runtime.v2.runtime.property,org.glassfish.jaxb.runtime.v2.runtime.unmarshaller,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.output' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset.stax,javax.xml.stream,org.glassfish.jaxb.core.marshaller,org.glassfish.jaxb.runtime.marshaller,org.glassfish.jaxb.runtime.v2.runtime,org.jvnet.staxex,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.property' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,javax.xml.stream,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.v2.model.runtime,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.reflect,org.glassfish.jaxb.runtime.v2.runtime.unmarshaller,org.glassfish.jaxb.runtime.v2.util,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.reflect' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,jakarta.xml.bind.annotation.adapters,javax.xml.stream,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.v2.model.runtime,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.unmarshaller,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.reflect.opt' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.stream,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.reflect,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.unmarshaller' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,jakarta.xml.bind,jakarta.xml.bind.annotation,jakarta.xml.bind.annotation.adapters,jakarta.xml.bind.attachment,jakarta.xml.bind.helpers,javax.xml.namespace,javax.xml.stream,javax.xml.transform,javax.xml.transform.sax,javax.xml.validation,org.glassfish.jaxb.core.unmarshaller,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.runtime.unmarshaller,org.glassfish.jaxb.runtime,org.glassfish.jaxb.runtime.api,org.glassfish.jaxb.runtime.util,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.output,org.glassfish.jaxb.runtime.v2.runtime.reflect,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.schemagen' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.txw2.output,jakarta.xml.bind,javax.xml.namespace,org.glassfish.jaxb.core.api,org.glassfish.jaxb.core.v2.model.core,org.glassfish.jaxb.core.v2.model.nav' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.schemagen.xmlschema' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.txw2,com.sun.xml.txw2.annotation,javax.xml.namespace' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.glassfish.jaxb.runtime.v2.util' version='4.0.8'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,javax.xml.namespace,javax.xml.transform.stream,org.glassfish.jaxb.runtime.v2.runtime,org.glassfish.jaxb.runtime.v2.runtime.unmarshaller,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.fastinfoset' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='com.sun.xml.fastinfoset.vocab,javax.xml.namespace,javax.xml.transform.sax,org.xml.sax,org.xml.sax.ext' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.fastinfoset.sax' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.jvnet.fastinfoset,org.xml.sax,org.xml.sax.ext' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.fastinfoset.sax.helpers' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.jvnet.fastinfoset,org.jvnet.fastinfoset.sax,org.xml.sax,org.xml.sax.ext,org.xml.sax.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.fastinfoset.stax' version='2.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.stream' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.staxex' version='2.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation,javax.xml.namespace,javax.xml.stream' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.jvnet.staxex.util' version='2.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind.attachment,javax.xml.namespace,javax.xml.stream,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='com.sun.xml.bind.jaxb-osgi' version='4.0.8'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='jakarta.xml.bind.JAXBContextFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='com.sun.tools.xjc.Plugin' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='com.sun.tools.rngdatatype.DatatypeLibraryFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='193'>
        <required namespace='java.package' name='jakarta.xml.bind' range='4.0.5'/>
        <required namespace='java.package' name='jakarta.xml.bind.annotation' range='4.0.5'/>
        <required namespace='java.package' name='jakarta.xml.bind.annotation.adapters' range='4.0.5'/>
        <required namespace='java.package' name='jakarta.xml.bind.attachment' range='4.0.5'/>
        <required namespace='java.package' name='jakarta.xml.bind.helpers' range='4.0.5'/>
        <required namespace='java.package' name='javax.xml.bind.annotation' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.source.tree' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.source.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant.taskdefs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant.taskdefs.compilers' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.tools.ant.types' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='com.sun.codemodel' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.codemodel.fmt' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.codemodel.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.codemodel.writer' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.istack' range='[4.1.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.istack.tools' range='[4.1.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc.ap' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc.api' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc.api.impl.j2s' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc.gen.config' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.jxc.model.nav' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngdatatype' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngdatatype.helpers' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.ast.builder' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.ast.om' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.ast.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.binary' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.binary.visitor' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.digested' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.dt' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.dt.builtin' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.nc' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.parse' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.parse.compact' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.parse.host' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.parse.xml' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.xml.sax' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.rngom.xml.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.api' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.api.impl.s2j' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.generator.annotation.spec' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.generator.bean' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.generator.bean.field' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.model' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.model.nav' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.outline' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.dtd' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.dtd.bindinfo' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.gbind' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.internalizer' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.relaxng' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.bindinfo' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.ct' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.reader.xmlschema.parser' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.runtime' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.tools.xjc.writer' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.dtdparser' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.algorithm' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.alphabet' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.dom' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.org.apache.xerces.util' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.sax' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.stax' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.stax.events' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.stax.util' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.tools' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.util' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.fastinfoset.vocab' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.txw2' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.txw2.annotation' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.txw2.output' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.impl' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.impl.parser' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.impl.parser.state' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.impl.scd' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.impl.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.parser' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='com.sun.xml.xsom.visitor' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='jakarta.activation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='java.awt' range='0.0.0'/>
        <required namespace='java.package' name='java.awt.image' range='0.0.0'/>
        <required namespace='java.package' name='java.beans' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.annotation' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.invoke' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.math' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.nio' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.file' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.time' range='0.0.0'/>
        <required namespace='java.package' name='java.time.format' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent' range='0.0.0'/>
        <required namespace='java.package' name='java.util.concurrent.locks' range='0.0.0'/>
        <required namespace='java.package' name='java.util.function' range='0.0.0'/>
        <required namespace='java.package' name='java.util.jar' range='0.0.0'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0'/>
        <required namespace='java.package' name='java.util.regex' range='0.0.0'/>
        <required namespace='java.package' name='java.util.stream' range='0.0.0'/>
        <required namespace='java.package' name='java.util.zip' range='0.0.0'/>
        <required namespace='java.package' name='javax.annotation.processing' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.imageio' range='0.0.0'/>
        <required namespace='java.package' name='javax.imageio.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.lang.model' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model.element' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model.type' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.lang.model.util' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.swing' range='0.0.0'/>
        <required namespace='java.package' name='javax.swing.border' range='0.0.0'/>
        <required namespace='java.package' name='javax.swing.tree' range='0.0.0'/>
        <required namespace='java.package' name='javax.tools' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.catalog' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream.events' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream.util' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.sax' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.validation' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.xpath' range='0.0.0'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.annotation' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.api' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.api.impl' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.marshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.unmarshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.model.annotation' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.model.core' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.model.impl' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.model.nav' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.model.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.runtime' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.runtime.unmarshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.schemagen.episode' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.core.v2.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.api' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.marshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.unmarshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.annotation' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.impl' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.model.runtime' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.output' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.property' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.reflect' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.runtime.unmarshaller' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.schemagen' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.schemagen.xmlschema' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.glassfish.jaxb.runtime.v2.util' range='[4.0.0,5.0.0)'/>
        <required namespace='java.package' name='org.jvnet.fastinfoset' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.jvnet.fastinfoset.sax' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.jvnet.fastinfoset.stax' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.jvnet.staxex' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.relaxng.datatype' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom.ls' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='jdk.internal.misc' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            com.sun.xml.bind.jaxb-osgi
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=com.sun.tools.xjc.Plugin)' min='0' greedy='false'>
          <description>
            com.sun.xml.bind.jaxb-osgi
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=com.sun.tools.rngdatatype.DatatypeLibraryFactory)' min='0' greedy='false'>
          <description>
            com.sun.xml.bind.jaxb-osgi
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.registrar)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            com.sun.xml.bind.jaxb-osgi
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            com.sun.xml.bind.jaxb-osgi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind.jaxb-osgi.source' range='[4.0.8,4.0.8]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.sun.xml.bind.jaxb-osgi' version='4.0.8'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.sun.xml.bind.jaxb-osgi&#xA;Bundle-Version: 4.0.8
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='io.github.classgraph.classgraph' version='4.8.184' singleton='false' generation='2'>
      <update id='io.github.classgraph.classgraph' range='[0.0.0,4.8.184)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ClassGraph'/>
        <property name='org.eclipse.equinox.p2.description' value='The uber-fast, ultra-lightweight classpath and module scanner for JVM languages.'/>
        <property name='org.eclipse.equinox.p2.provider' value='Luke Hutchison'/>
        <property name='maven-groupId' value='io.github.classgraph'/>
        <property name='maven-artifactId' value='classgraph'/>
        <property name='maven-version' value='4.8.184'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='io.github.classgraph.classgraph' version='4.8.184'/>
        <provided namespace='osgi.bundle' name='io.github.classgraph.classgraph' version='4.8.184'/>
        <provided namespace='java.package' name='io.github.classgraph' version='4.8.184'/>
        <provided namespace='osgi.identity' name='io.github.classgraph.classgraph' version='4.8.184'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='java.package' name='javax.xml.xpath' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='sun.misc' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='sun.nio.ch' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='io.github.toolfactory.narcissus' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='io.github.toolfactory.jvm' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            io.github.classgraph.classgraph
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.github.classgraph.classgraph.source' range='[4.8.184,4.8.184]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='io.github.classgraph.classgraph' version='4.8.184'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: io.github.classgraph.classgraph&#xA;Bundle-Version: 4.8.184
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='jakarta.activation-api' version='2.1.4' singleton='false' generation='2'>
      <update id='jakarta.activation-api' range='[0.0.0,2.1.4)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Jakarta Activation API'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta Activation API 2.1 Specification'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='jakarta.activation'/>
        <property name='maven-artifactId' value='jakarta.activation-api'/>
        <property name='maven-version' value='2.1.4'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='jakarta.activation-api' version='2.1.4'/>
        <provided namespace='osgi.bundle' name='jakarta.activation-api' version='2.1.4'/>
        <provided namespace='java.package' name='jakarta.activation' version='2.1.4'/>
        <provided namespace='java.package' name='jakarta.activation.spi' version='2.1.4'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='jakarta.activation-api' version='2.1.4'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='jakarta.activation' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.activation.spi' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            jakarta.activation-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=jakarta.activation.spi.MailcapRegistryProvider)' min='0' greedy='false'>
          <description>
            jakarta.activation-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=jakarta.activation.spi.MimeTypeRegistryProvider)' min='0' greedy='false'>
          <description>
            jakarta.activation-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            jakarta.activation-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.activation-api.source' range='[2.1.4,2.1.4]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='jakarta.activation-api' version='2.1.4'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: jakarta.activation-api&#xA;Bundle-Version: 2.1.4
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='jakarta.inject.jakarta.inject-api' version='2.0.1' singleton='false' generation='2'>
      <update id='jakarta.inject.jakarta.inject-api' range='[0.0.0,2.0.1)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Jakarta Dependency Injection'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta Dependency Injection'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='jakarta.inject'/>
        <property name='maven-artifactId' value='jakarta.inject-api'/>
        <property name='maven-version' value='2.0.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
        <provided namespace='osgi.bundle' name='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
        <provided namespace='java.package' name='jakarta.inject' version='2.0.1'/>
        <provided namespace='osgi.identity' name='jakarta.inject.jakarta.inject-api' version='2.0.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            jakarta.inject.jakarta.inject-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.inject.jakarta.inject-api.source' range='[2.0.1,2.0.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='jakarta.inject.jakarta.inject-api' version='2.0.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: jakarta.inject.jakarta.inject-api&#xA;Bundle-Version: 2.0.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='jakarta.xml.bind-api' version='4.0.5' singleton='false' generation='2'>
      <update id='jakarta.xml.bind-api' range='[0.0.0,4.0.5)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Jakarta XML Binding API'/>
        <property name='org.eclipse.equinox.p2.description' value='Jakarta XML Binding API 4.0 Design Specification'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.eclipse.org'/>
        <property name='maven-groupId' value='jakarta.xml.bind'/>
        <property name='maven-artifactId' value='jakarta.xml.bind-api'/>
        <property name='maven-version' value='4.0.5'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='jakarta.xml.bind-api' version='4.0.5'/>
        <provided namespace='osgi.bundle' name='jakarta.xml.bind-api' version='4.0.5'/>
        <provided namespace='java.package' name='jakarta.xml.bind' version='4.0.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind.annotation.adapters,jakarta.xml.bind.attachment,javax.xml.namespace,javax.xml.stream,javax.xml.transform,javax.xml.validation,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='jakarta.xml.bind.annotation' version='4.0.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,javax.xml.parsers,javax.xml.transform,javax.xml.transform.dom,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='jakarta.xml.bind.annotation.adapters' version='4.0.5'/>
        <provided namespace='java.package' name='jakarta.xml.bind.attachment' version='4.0.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.activation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='jakarta.xml.bind.helpers' version='4.0.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,jakarta.xml.bind.annotation.adapters,jakarta.xml.bind.attachment,javax.xml.stream,javax.xml.transform,javax.xml.validation,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='jakarta.xml.bind.util' version='4.0.5'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='jakarta.xml.bind,javax.xml.transform.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='jakarta.xml.bind-api' version='4.0.5'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='37'>
        <required namespace='java.package' name='jakarta.activation' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='jakarta.xml.bind' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.xml.bind.annotation' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.xml.bind.annotation.adapters' range='0.0.0'/>
        <required namespace='java.package' name='jakarta.xml.bind.attachment' range='0.0.0'/>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.annotation' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.invoke' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.ref' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.math' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.nio.charset' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.function' range='0.0.0'/>
        <required namespace='java.package' name='java.util.logging' range='0.0.0'/>
        <required namespace='java.package' name='java.util.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.sax' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.validation' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            jakarta.xml.bind-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=jakarta.xml.bind.JAXBContextFactory)' min='0' greedy='false'>
          <description>
            jakarta.xml.bind-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            jakarta.xml.bind-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.xml.bind-api.source' range='[4.0.5,4.0.5]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='jakarta.xml.bind-api' version='4.0.5'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: jakarta.xml.bind-api&#xA;Bundle-Version: 4.0.5
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.antlr.runtime' version='3.2.0.v20230929-1400' singleton='false' generation='2'>
      <update id='org.antlr.runtime' range='[0.0.0,3.2.0.v20230929-1400)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle org.antlr : antlr-runtime'/>
        <property name='maven-wrapped-groupId' value='org.antlr'/>
        <property name='maven-wrapped-artifactId' value='antlr-runtime'/>
        <property name='maven-wrapped-version' value='3.2'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.antlr.runtime' version='3.2.0.v20230929-1400'/>
        <provided namespace='osgi.bundle' name='org.antlr.runtime' version='3.2.0.v20230929-1400'/>
        <provided namespace='java.package' name='org.antlr.runtime' version='3.2.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.debug' version='3.2.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.misc' version='3.2.0'/>
        <provided namespace='java.package' name='org.antlr.runtime.tree' version='3.2.0'/>
        <provided namespace='osgi.identity' name='org.antlr.runtime' version='3.2.0.v20230929-1400'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.antlr.stringtemplate' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.4))'>
          <description>
            org.antlr.runtime
          </description>
        </requiredProperties>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.antlr.runtime' version='3.2.0.v20230929-1400'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.antlr.runtime&#xA;Bundle-Version: 3.2.0.v20230929-1400
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.aopalliance' version='1.0.0.v20230720-0728' singleton='false' generation='2'>
      <update id='org.aopalliance' range='[0.0.0,1.0.0.v20230720-0728)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle aopalliance : aopalliance'/>
        <property name='maven-wrapped-groupId' value='aopalliance'/>
        <property name='maven-wrapped-artifactId' value='aopalliance'/>
        <property name='maven-wrapped-version' value='1.0'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.aopalliance' version='1.0.0.v20230720-0728'/>
        <provided namespace='osgi.bundle' name='org.aopalliance' version='1.0.0.v20230720-0728'/>
        <provided namespace='java.package' name='org.aopalliance.aop' version='1.0.0'/>
        <provided namespace='java.package' name='org.aopalliance.intercept' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.aopalliance.aop' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.aopalliance' version='1.0.0.v20230720-0728'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.3))'>
          <description>
            org.aopalliance
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.aopalliance.source' range='[1.0.0.v20230720-0728,1.0.0.v20230720-0728]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.aopalliance' version='1.0.0.v20230720-0728'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.aopalliance&#xA;Bundle-Version: 1.0.0.v20230720-0728
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.aries.spifly.dynamic.bundle' version='1.3.7' singleton='false' generation='2'>
      <update id='org.apache.aries.spifly.dynamic.bundle' range='[0.0.0,1.3.7)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Aries SPI Fly Dynamic Weaving Bundle'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle contains an extender that facilitates the use         of JRE SPI providers (components typically plugged in to the         JRE through META-INF/services resources).'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.apache.org/spifly/org.apache.aries.spifly.dynamic.bundle/'/>
        <property name='maven-groupId' value='org.apache.aries.spifly'/>
        <property name='maven-artifactId' value='org.apache.aries.spifly.dynamic.bundle'/>
        <property name='maven-version' value='1.3.7'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.aries.spifly.dynamic.bundle' version='1.3.7'/>
        <provided namespace='osgi.bundle' name='org.apache.aries.spifly.dynamic.bundle' version='1.3.7'/>
        <provided namespace='java.package' name='org.apache.aries.spifly' version='1.3.7'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.util.tracker' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.aries.spifly.dynamic' version='1.3.7'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.aries.spifly,org.objectweb.asm,org.osgi.framework,org.osgi.framework.hooks.weaving' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.aries.spifly.weaver' version='1.3.7'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.aries.spifly,org.objectweb.asm' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.aries.spifly.dynamic.bundle' version='1.3.7'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.serviceloader.registrar' version='1.0.0'/>
        <provided namespace='osgi.extender' name='osgi.serviceloader.processor' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='java.package' name='org.apache.aries.spifly.weaver' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.objectweb.asm' range='[9.6.0,10.0.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.commons' range='[9.6.0,10.0.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.util' range='[9.6.0,10.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.7.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.weaving' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.aries.spifly.dynamic.bundle
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.aries.spifly.dynamic.bundle.source' range='[1.3.7,1.3.7]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.aries.spifly.dynamic.bundle' version='1.3.7'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.aries.spifly.dynamic.bundle&#xA;Bundle-Version: 1.3.7
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.2.0' singleton='false'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.2.0)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Commons Logging'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Commons Logging is a thin adapter allowing configurable bridging to other,    well known logging systems.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://commons.apache.org/proper/commons-logging/'/>
        <property name='maven-groupId' value='commons-logging'/>
        <property name='maven-artifactId' value='commons-logging'/>
        <property name='maven-version' value='1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.2.0'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.2.0'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.apache.commons.logging' version='1.2.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='javax.servlet' range='[2.1.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.avalon.framework.logger' range='[4.1.3,4.1.5]' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log' range='[1.0.1,1.0.1]' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='[1.2.15,2.0.0)' optional='true' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging.source' range='[1.2.0,1.2.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.2.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.2.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.2.18' singleton='false' generation='2'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.2.18)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.5'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
        <property name='maven-groupId' value='org.apache.felix'/>
        <property name='maven-artifactId' value='org.apache.felix.scr'/>
        <property name='maven-version' value='2.2.18'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.2.18'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.2.18'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.component' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.apache.felix.scr' version='2.2.18'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.extender' name='osgi.component' version='1.5.0'/>
        <provided namespace='osgi.service' name='org.apache.felix.scr_2.2.18-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.component.runtime.ServiceComponentRuntime' type='List'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='22'>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.6.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.resource' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(|(&amp;(osgi.ee=JavaSE)(version=1.7))(&amp;(osgi.ee=JavaSE/compact1)(version=1.8)))'>
          <description>
            org.apache.felix.scr
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr.source' range='[2.2.18,2.2.18]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.2.18'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.2.18
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.log4j' version='1.2.26' singleton='false' generation='2'>
      <update id='org.apache.log4j' range='[0.0.0,1.2.26)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='reload4j'/>
        <property name='org.eclipse.equinox.p2.description' value='Reload4j revives EOLed log4j 1.x'/>
        <property name='org.eclipse.equinox.p2.provider' value='QOS.CH Sarl (Switzerland)'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://reload4j.qos.ch/'/>
        <property name='maven-groupId' value='ch.qos.reload4j'/>
        <property name='maven-artifactId' value='reload4j'/>
        <property name='maven-version' value='1.2.26'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j' version='1.2.26'/>
        <provided namespace='osgi.bundle' name='org.apache.log4j' version='1.2.26'/>
        <provided namespace='java.package' name='org.apache.log4j' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j.helpers,org.apache.log4j.or,org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.config' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.helpers' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.jdbc' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.net' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.jms,javax.mail,javax.naming,org.apache.log4j,org.apache.log4j.helpers,org.apache.log4j.spi,org.apache.log4j.xml,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.or' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.or.jms' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j.or' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.or.sax' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j.or' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.pattern' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.helpers,org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.rewrite' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.spi,org.apache.log4j.xml,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.spi' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.or' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.varia' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.log4j,org.apache.log4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.log4j.xml' version='1.2.26'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.apache.log4j,org.apache.log4j.config,org.apache.log4j.spi,org.w3c.dom,org.xml.sax' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.log4j' version='1.2.26'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='javax.jmdns' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.jms' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.mail.internet' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.apache.log4j
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.log4j.source' range='[1.2.26,1.2.26]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.log4j' version='1.2.26'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.log4j&#xA;Bundle-Version: 1.2.26
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.logging.log4j.api' version='2.26.0' singleton='false' generation='2'>
      <update id='org.apache.logging.log4j.api' range='[0.0.0,2.26.0)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='Apache Log4j API'/>
        <property name='org.eclipse.equinox.p2.description' value='The logging API of the Log4j project.     Library and application code can log through this API.     It contains a simple built-in implementation (`SimpleLogger`) for trivial use cases.     Production applications are recommended to use Log4j API in combination with a fully-fledged implementation, such as Log4j Core.'/>
        <property name='org.eclipse.equinox.p2.provider' value='The Apache Software Foundation'/>
        <property name='maven-groupId' value='org.apache.logging.log4j'/>
        <property name='maven-artifactId' value='log4j-api'/>
        <property name='maven-version' value='2.26.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.logging.log4j.api' version='2.26.0'/>
        <provided namespace='osgi.bundle' name='org.apache.logging.log4j.api' version='2.26.0'/>
        <provided namespace='java.package' name='org.apache.logging.log4j' version='2.20.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j.message,org.apache.logging.log4j.spi,org.apache.logging.log4j.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.logging.log4j.message' version='2.24.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.logging.log4j.simple' version='2.25.3'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j,org.apache.logging.log4j.message,org.apache.logging.log4j.spi,org.apache.logging.log4j.util,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.logging.log4j.spi' version='2.25.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j,org.apache.logging.log4j.message,org.apache.logging.log4j.util,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.logging.log4j.status' version='2.25.3'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j,org.apache.logging.log4j.message,org.apache.logging.log4j.spi,org.jspecify.annotations' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.apache.logging.log4j.util' version='2.25.3'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.apache.logging.log4j,org.apache.logging.log4j.message,org.apache.logging.log4j.spi,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.apache.logging.log4j.api' version='2.26.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.apache.logging.log4j.api_2.26.0-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.apache.logging.log4j.util.PropertySource' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.apache.logging.log4j.util.PropertySource' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.apache.logging.log4j.util.PropertySource' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='java.package' name='org.jspecify.annotations' range='[1.0.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.logging.log4j.status' range='[2.25.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.registrar)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))' min='0' greedy='false'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=org.apache.logging.log4j.message.ThreadDumpMessage$ThreadInfoFactory)' min='0' greedy='false'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=org.apache.logging.log4j.spi.Provider)' min='0' greedy='false'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=org.apache.logging.log4j.util.PropertySource)' min='0' greedy='false'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.apache.logging.log4j.api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.logging.log4j.api.source' range='[2.26.0,2.26.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.logging.log4j.api' version='2.26.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.logging.log4j.api&#xA;Bundle-Version: 2.26.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.12.500.v20251103-0733' singleton='false' generation='2'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.12.500.v20251103-0733)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.commands'/>
        <property name='maven-version' value='3.12.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.commands' version='3.12.500.v20251103-0733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.commands
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands.source' range='[3.12.500.v20251103-0733,3.12.500.v20251103-0733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.12.500.v20251103-0733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.12.500.v20251103-0733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620' generation='2'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.9.800.v20251105-1620)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.contenttype'/>
        <property name='maven-version' value='3.9.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.13.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.2)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.contenttype
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype.source' range='[3.9.800.v20251105-1620,3.9.800.v20251105-1620]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.9.800.v20251105-1620'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.9.800.v20251105-1620
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.9.600.v20260514-2026' generation='2'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.9.600.v20260514-2026)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.expressions'/>
        <property name='maven-version' value='3.9.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.9.600.v20260514-2026'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.9.600.v20260514-2026'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.expressions' version='3.9.600.v20260514-2026'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.expressions
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions.source' range='[3.9.600.v20260514-2026,3.9.600.v20260514-2026]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.9.600.v20260514-2026'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.9.600.v20260514-2026
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem' version='1.11.400.v20251107-0507' generation='2'>
      <update id='org.eclipse.core.filesystem' range='[0.0.0,1.11.400.v20251107-0507)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core File Systems'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.filesystem'/>
        <property name='maven-version' value='1.11.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' version='1.11.400.v20251107-0507'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem' version='1.11.400.v20251107-0507'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local.unix' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.filesystem' version='1.11.400.v20251107-0507'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='java.package' name='com.sun.jna' range='[5.14.0,6.0.0)'/>
        <required namespace='java.package' name='com.sun.jna.platform.win32' range='[5.14.0,6.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.filesystem
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.source' range='[1.11.400.v20251107-0507,1.11.400.v20251107-0507]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem' version='1.11.400.v20251107-0507'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem; singleton:=true&#xA;Bundle-Version: 1.11.400.v20251107-0507
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.15.800.v20260325-1353' generation='2'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.15.800.v20260325-1353)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.15.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.15.800.v20260325-1353'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.15.800.v20260325-1353'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.jobs' version='3.15.800.v20260325-1353'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.jobs
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs.source' range='[3.15.800.v20260325-1353,3.15.800.v20260325-1353]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.15.800.v20260325-1353'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.15.800.v20260325-1353
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources' version='3.24.0.v20260518-1150' generation='2'>
      <update id='org.eclipse.core.resources' range='[0.0.0,3.24.0.v20260518-1150)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Resource Management'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.resources'/>
        <property name='maven-version' value='3.24.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' version='3.24.0.v20260518-1150'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources' version='3.24.0.v20260518-1150'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.dtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.localstore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.projectvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.refresh.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.watson' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.filtermatchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.team' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.undo.snapshot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.variableresolvers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.resources' version='3.24.0.v20260518-1150'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='[3.7.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.11.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.34.0,4.0.0)'/>
        <required namespace='java.package' name='com.sun.jna' range='[5.17.0,6.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.4.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.resources
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.source' range='[3.24.0.v20260518-1150,3.24.0.v20260518-1150]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources' version='3.24.0.v20260518-1150'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources; singleton:=true&#xA;Bundle-Version: 3.24.0.v20260518-1150
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.34.200.v20251220-0953' generation='2'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.34.200.v20251220-0953)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.runtime'/>
        <property name='maven-version' value='3.34.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.23.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.20.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.15.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.12.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.12.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.7.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.runtime
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.source' range='[3.34.200.v20251220-0953,3.34.200.v20251220-0953]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.34.200.v20251220-0953'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.34.200.v20251220-0953
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.variables' version='3.6.800.v20260427-0433' generation='2'>
      <update id='org.eclipse.core.variables' range='[0.0.0,3.6.800.v20260427-0433)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Core Variables'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.core.variables'/>
        <property name='maven-version' value='3.6.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' version='3.6.800.v20260427-0433'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.variables' version='3.6.800.v20260427-0433'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.variables' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.core.variables' version='3.6.800.v20260427-0433'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.core.variables
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables.source' range='[3.6.800.v20260427-0433,3.6.800.v20260427-0433]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.variables' version='3.6.800.v20260427-0433'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.variables; singleton:=true&#xA;Bundle-Version: 3.6.800.v20260427-0433
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.debug.core' version='3.23.300.v20260513-0740' generation='2'>
      <update id='org.eclipse.debug.core' range='[0.0.0,3.23.300.v20260513-0740)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Debug Core'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.debug.core'/>
        <property name='maven-version' value='3.23.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' version='3.23.300.v20260513-0740'/>
        <provided namespace='osgi.bundle' name='org.eclipse.debug.core' version='3.23.300.v20260513-0740'/>
        <provided namespace='java.package' name='org.eclipse.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.groups' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.groups.observer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.variables' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.debug.core' version='3.23.300.v20260513-0740'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.800,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.11.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.debug.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core.source' range='[3.23.300.v20260513-0740,3.23.300.v20260513-0740]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.debug.core' version='3.23.300.v20260513-0740'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.debug.core; singleton:=true&#xA;Bundle-Version: 3.23.300.v20260513-0740
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.codegen' version='2.28.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.codegen' range='[0.0.0,2.28.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Code Generation'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.codegen'/>
        <property name='maven-version' value='2.28.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen' version='2.28.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.codegen' version='2.28.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.jet' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.jmerge' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.merge.java' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.merge.java.facade' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.merge.java.facade.ast' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.merge.java.facade.jdom' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.merge.properties' version='2.28.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.util' version='2.28.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.codegen' version='2.28.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.45.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core' range='[3.26.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.launching' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.codegen
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.source' range='[2.28.0.v20251210-1145,2.28.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.codegen' version='2.28.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.codegen; singleton:=true&#xA;Bundle-Version: 2.28.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.codegen.ecore' version='2.46.0.v20260311-1301' generation='2'>
      <update id='org.eclipse.emf.codegen.ecore' range='[0.0.0,2.46.0.v20260311-1301)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Ecore Code Generator'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.codegen.ecore'/>
        <property name='maven-version' value='2.46.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore' version='2.46.0.v20260311-1301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore' version='2.46.0.v20260311-1301'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.generator' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.genmodel' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.genmodel.generator' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.genmodel.impl' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.genmodel.util' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.gwt' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.templates.edit' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.templates.editor' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.templates.model' version='2.46.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.templates.model.tests' version='2.46.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.codegen.ecore' version='2.46.0.v20260311-1301'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.codegen.ecore_2.46.0.v20260311-1301-1' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2002/GenModel'/>
            <property name='genModel' value='model/GenModel.genmodel'/>
            <property name='class' value='org.eclipse.emf.codegen.ecore.genmodel.GenModelPackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core' range='[3.26.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.launching' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.42.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen' range='[2.28.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='[2.40.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.codegen.ecore
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore.source' range='[2.46.0.v20260311-1301,2.46.0.v20260311-1301]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.codegen.ecore' version='2.46.0.v20260311-1301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.codegen.ecore;singleton:=true&#xA;Bundle-Version: 2.46.0.v20260311-1301
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0.v20250910-1205' generation='2'>
      <update id='org.eclipse.emf.codegen.ecore.xtext' range='[0.0.0,1.8.0.v20250910-1205)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Ecore Code Generator Xtext Integration'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.codegen.ecore.xtext'/>
        <property name='maven-version' value='1.8.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0.v20250910-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0.v20250910-1205'/>
        <provided namespace='java.package' name='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0.v20250910-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore' range='[2.36.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.mwe2.runtime' range='[2.9.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.codegen.ecore.xtext
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.codegen.ecore.xtext.source' range='[1.8.0.v20250910-1205,1.8.0.v20250910-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.codegen.ecore.xtext' version='1.8.0.v20250910-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.codegen.ecore.xtext;singleton:=true&#xA;Bundle-Version: 1.8.0.v20250910-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.common' version='2.45.0.v20260311-1301' generation='2'>
      <update id='org.eclipse.emf.common' range='[0.0.0,2.45.0.v20260311-1301)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Common'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.common'/>
        <property name='maven-version' value='2.45.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' version='2.45.0.v20260311-1301'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.common' version='2.45.0.v20260311-1301'/>
        <provided namespace='java.package' name='org.eclipse.emf.common' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.archive' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.command' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.notify.impl' version='2.45.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.common.util' version='2.45.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.common' version='2.45.0.v20260311-1301'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.common
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.source' range='[2.45.0.v20260311-1301,2.45.0.v20260311-1301]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.common' version='2.45.0.v20260311-1301'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.common;singleton:=true&#xA;Bundle-Version: 2.45.0.v20260311-1301
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.ecore' range='[0.0.0,2.42.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Ecore'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore'/>
        <property name='maven-version' value='2.42.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.plugin' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.resource.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.util' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.namespace.util' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.impl' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.internal' version='2.42.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xml.type.util' version='2.42.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-1' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2002/Ecore'/>
            <property name='genModel' value='model/Ecore.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.EcorePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-2' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.w3.org/XML/1998/namespace'/>
            <property name='genModel' value='model/XMLNamespace.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.xml.namespace.XMLNamespacePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-3' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2003/XMLType'/>
            <property name='genModel' value='model/XMLType.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.xml.type.XMLTypePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-4' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/ExtendedMetaData.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/ExtendedMetaData'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-5' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/EcoreAnnotation.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/EcoreAnnotation'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.dynamic_package' name='org.eclipse.emf.ecore_2.42.0.v20251210-1145-6' version='0.0.0'>
          <properties size='2'>
            <property name='location' value='model/DateConversionDelegateAnnotation.ecore'/>
            <property name='uri' value='http:///org/eclipse/emf/ecore/util/DateConversionDelegateAnnotation'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.45.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.8.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.datatype' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.source' range='[2.42.0.v20251210-1145,2.42.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore' version='2.42.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore;singleton:=true&#xA;Bundle-Version: 2.42.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205' generation='2'>
      <update id='org.eclipse.emf.ecore.change' range='[0.0.0,2.17.0.v20250910-1205)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Change Model'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.change'/>
        <property name='maven-version' value='2.17.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change' version='2.17.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.impl' version='2.17.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.change.util' version='2.17.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.emf.ecore.generated_package' name='org.eclipse.emf.ecore.change_2.17.0.v20250910-1205-1' version='0.0.0'>
          <properties size='3'>
            <property name='uri' value='http://www.eclipse.org/emf/2003/Change'/>
            <property name='genModel' value='model/Change.genmodel'/>
            <property name='class' value='org.eclipse.emf.ecore.change.ChangePackage'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.37.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.change
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change.source' range='[2.17.0.v20250910-1205,2.17.0.v20250910-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.change' version='2.17.0.v20250910-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.change;singleton:=true&#xA;Bundle-Version: 2.17.0.v20250910-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.xcore' version='1.37.0.v20260322-1106' generation='2'>
      <update id='org.eclipse.emf.ecore.xcore' range='[0.0.0,1.37.0.v20260322-1106)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Xcore'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xcore'/>
        <property name='maven-version' value='1.37.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore' version='1.37.0.v20260322-1106'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore' version='1.37.0.v20260322-1106'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.conversion' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.findrefs' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.formatting' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.generator' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.impl' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.interpreter' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.mappings' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.parser.antlr' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.parser.antlr.internal' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.resource' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.resource.containers' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.scoping' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.scoping.types' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.serializer' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.services' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.util' version='1.37.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.validation' version='1.37.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.xcore' version='1.37.0.v20260322-1106'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='[2.13.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.42.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.util' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.antlr.runtime' range='[3.2.0,3.2.1)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.common.types' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.ecore' range='[2.18.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore.lib' range='[1.7.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore.xtext' range='[1.8.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.codegen.ecore' range='[2.46.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.objectweb.asm' range='[5.0.0,11.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.slf4j' range='[1.7.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.xcore
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.source' range='[1.37.0.v20260322-1106,1.37.0.v20260322-1106]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.xcore' version='1.37.0.v20260322-1106'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.xcore;singleton:=true&#xA;Bundle-Version: 1.37.0.v20260322-1106
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.xcore.lib' version='1.7.1.v20250910-1205' generation='2'>
      <update id='org.eclipse.emf.ecore.xcore.lib' range='[0.0.0,1.7.1.v20250910-1205)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF Xcore Library Runtime Library'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xcore.lib'/>
        <property name='maven-version' value='1.7.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.lib' version='1.7.1.v20250910-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.xcore.lib' version='1.7.1.v20250910-1205'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xcore.lib' version='1.7.1'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.xcore.lib' version='1.7.1.v20250910-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.39.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='[2.42.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='[2.18.0,3.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.xcore.lib
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xcore.lib.source' range='[1.7.1.v20250910-1205,1.7.1.v20250910-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.xcore.lib' version='1.7.1.v20250910-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.xcore.lib;singleton:=true&#xA;Bundle-Version: 1.7.1.v20250910-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145' generation='2'>
      <update id='org.eclipse.emf.ecore.xmi' range='[0.0.0,2.40.0.v20251210-1145)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='EMF XML/XMI Persistence'/>
        <property name='df_LT.providerName' value='Eclipse Modeling Project'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.ecore.xmi'/>
        <property name='maven-version' value='2.40.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi' version='2.40.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.impl' version='2.40.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.ecore.xmi.util' version='2.40.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.9.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='[2.42.0,3.0.0)'/>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.emf.ecore.xmi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi.source' range='[2.40.0.v20251210-1145,2.40.0.v20251210-1145]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.ecore.xmi' version='2.40.0.v20251210-1145'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.ecore.xmi; singleton:=true&#xA;Bundle-Version: 2.40.0.v20251210-1145
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.emf.mwe2.runtime' version='2.26.0.v20260523-1243' singleton='false' generation='2'>
      <update id='org.eclipse.emf.mwe2.runtime' range='[0.0.0,2.26.0.v20260523-1243)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='MWE2 Runtime'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.emf'/>
        <property name='maven-artifactId' value='org.eclipse.emf.mwe2.runtime'/>
        <property name='maven-version' value='2.26.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.runtime' version='2.26.0.v20260523-1243'/>
        <provided namespace='osgi.bundle' name='org.eclipse.emf.mwe2.runtime' version='2.26.0.v20260523-1243'/>
        <provided namespace='java.package' name='org.eclipse.emf.mwe2.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.emf.mwe2.runtime.workflow' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.emf.mwe2.runtime' version='2.26.0.v20260523-1243'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='com.google.inject' range='7.0.0'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.24'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.emf.mwe2.runtime
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.mwe2.runtime.source' range='[2.26.0.v20260523-1243,2.26.0.v20260523-1243]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.emf.mwe2.runtime' version='2.26.0.v20260523-1243'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.emf.mwe2.runtime&#xA;Bundle-Version: 2.26.0.v20260523-1243
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.7.600.v20251211-1038' generation='2'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.7.600.v20251211-1038)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.app'/>
        <property name='maven-version' value='1.7.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.app
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app.source' range='[1.7.600.v20251211-1038,1.7.600.v20251211-1038]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.7.600.v20251211-1038'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.7.600.v20251211-1038
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.20.400.v20260512-1534' generation='2'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.20.400.v20260512-1534)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.20.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.20.400.v20260512-1534'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.20.400.v20260512-1534'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.attribute.common' value='split'/>
            <property name='java.package.directive.mandatory' value='common' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'>
          <properties size='3'>
            <property name='java.package.attribute.common' value='split'/>
            <property name='java.package.directive.mandatory' value='common' type='List'/>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.text' version='3.14.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.common' version='3.20.400.v20260512-1534'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.17.200,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.common
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common.source' range='[3.20.400.v20260512-1534,3.20.400.v20260512-1534]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.20.400.v20260512-1534'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.20.400.v20260512-1534
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.event' version='1.7.300.v20250518-0609' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.event' range='[0.0.0,1.7.300.v20250518-0609)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Event Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.event'/>
        <property name='maven-version' value='1.7.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event.mapper' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.equinox.event_1.7.300.v20250518-0609-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.event.EventAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.implementation' name='osgi.event' version='1.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.component)(version&gt;=1.0)(!(version&gt;=2.0)))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.event
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event.source' range='[1.7.300.v20250518-0609,1.7.300.v20250518-0609]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.event' version='1.7.300.v20250518-0609'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.event&#xA;Bundle-Version: 1.7.300.v20250518-0609
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin' version='2.3.600.v20260306-0554' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin' range='[0.0.0,2.3.600.v20260306-0554)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.frameworkadmin'/>
        <property name='maven-version' value='2.3.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' version='2.3.600.v20260306-0554'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin' version='2.3.600.v20260306-0554'/>
        <provided namespace='java.package' name='org.eclipse.equinox.frameworkadmin' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin' version='2.3.600.v20260306-0554'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.frameworkadmin
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.source' range='[2.3.600.v20260306-0554,2.3.600.v20260306-0554]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin' version='2.3.600.v20260306-0554'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin;singleton:=true&#xA;Bundle-Version: 2.3.600.v20260306-0554
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.400.v20250515-0513' generation='2'>
      <update id='org.eclipse.equinox.frameworkadmin.equinox' range='[0.0.0,1.3.400.v20250515-0513)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin for Equinox'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.frameworkadmin.equinox'/>
        <property name='maven-version' value='1.3.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.400.v20250515-0513'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.400.v20250515-0513'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.400.v20250515-0513'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.18.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.frameworkadmin.equinox
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox.source' range='[1.3.400.v20250515-0513,1.3.400.v20250515-0513]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin.equinox' version='1.3.400.v20250515-0513'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin.equinox;singleton:=true&#xA;Bundle-Version: 1.3.400.v20250515-0513
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.service.api' version='1.2.202.v20260307-0016' singleton='false' generation='2'>
      <update id='org.eclipse.equinox.http.service.api' range='[0.0.0,1.2.202.v20260307-0016)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='OSGi service http APIs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.http Version 1.2.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - Equinox'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.http.service.api'/>
        <property name='maven-version' value='1.2.202-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.service.api' version='1.2.202.v20260307-0016'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.service.api' version='1.2.202.v20260307-0016'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.102'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet,javax.servlet.http' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.http.service.api' version='1.2.202.v20260307-0016'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.contract' name='JavaServlet' version='2.6.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='3.0.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='3.1.0'/>
        <provided namespace='osgi.contract' name='JavaServlet' version='4.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='javax.servlet' range='[2.1.0,5.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.1.0,5.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.equinox.http.service.api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.service.api.source' range='[1.2.202.v20260307-0016,1.2.202.v20260307-0016]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.service.api' version='1.2.202.v20260307-0016'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.service.api&#xA;Bundle-Version: 1.2.202.v20260307-0016
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406' generation='2'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.7.100.v20251111-0406)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher'/>
        <property name='maven-version' value='1.7.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.launcher
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.source' range='[1.7.100.v20251111-0406,1.7.100.v20251111-0406]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.7.100.v20251111-0406
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'>
      <update id='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[0.0.0,1.2.1500.v20250801-0854)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Launcher Linux X86_64 Fragment'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.gtk.linux.x86_64'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher.gtk.linux.x86_64'/>
        <property name='maven-version' value='1.2.1500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'>
          <properties size='1'>
            <property name='type' value='osgi.fragment'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.2.1500.v20250801-0854'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.7.0,1.8.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64.source' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.gtk.linux.x86_64;singleton:=true&#xA;Bundle-Version: 1.2.1500.v20250801-0854&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.7.0,1.8.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.5.900.v20260319-1254' generation='2'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.5.900.v20260319-1254)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.artifact.repository'/>
        <property name='maven-version' value='1.5.900-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.900.v20260319-1254'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.900.v20260319-1254'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pgp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.artifact.repository' version='1.5.900.v20260319-1254'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='33'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.bc' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.jcajce' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator' range='1.65.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.12.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.artifact.repository
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository.source' range='[1.5.900.v20260319-1254,1.5.900.v20260319-1254]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.5.900.v20260319-1254'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.5.900.v20260319-1254
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.13.300.v20260108-1444' generation='2'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.13.300.v20260108-1444)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.core'/>
        <property name='maven-version' value='2.13.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.13.300.v20260108-1444'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.13.300.v20260108-1444'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.13.200'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.p2.core' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.core' version='2.13.300.v20260108-1444'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.core
          </description>
        </requiredProperties>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.source' range='[2.13.300.v20260108-1444,2.13.300.v20260108-1444]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.13.300.v20260108-1444'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.13.300.v20260108-1444
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.6.900.v20260512-1529' generation='2'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.6.900.v20260512-1529)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.director'/>
        <property name='maven-version' value='2.6.900-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.6.900.v20260512-1529'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.6.900.v20260512-1529'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.engine,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.director' version='2.6.900.v20260512-1529'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.8.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.3.5,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.3.5,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.director
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.source' range='[2.6.900.v20260512-1529,2.6.900.v20260512-1529]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.6.900.v20260512-1529'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.6.900.v20260512-1529
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.directorywatcher' version='1.4.800.v20250922-0444' generation='2'>
      <update id='org.eclipse.equinox.p2.directorywatcher' range='[0.0.0,1.4.800.v20250922-0444)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Directory Watcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.directorywatcher'/>
        <property name='maven-version' value='1.4.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' version='1.4.800.v20250922-0444'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.directorywatcher' version='1.4.800.v20250922-0444'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.directorywatcher' version='1.4.800.v20250922-0444'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.directorywatcher
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher.source' range='[1.4.800.v20250922-0444,1.4.800.v20250922-0444]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.directorywatcher' version='1.4.800.v20250922-0444'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.directorywatcher;singleton:=true&#xA;Bundle-Version: 1.4.800.v20250922-0444
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.11.100.v20260512-1529' generation='2'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.11.100.v20260512-1529)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.engine'/>
        <property name='maven-version' value='2.11.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.11.100.v20260512-1529'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.11.100.v20260512-1529'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.core.runtime.preferences,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.p2.engine,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.engine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.engine' version='2.11.100.v20260512-1529'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='40'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.65.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pgp' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.13.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.engine
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine.source' range='[2.11.100.v20260512-1529,2.11.100.v20260512-1529]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.11.100.v20260512-1529'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.11.100.v20260512-1529
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.extensionlocation' version='1.5.700.v20250720-1526' generation='2'>
      <update id='org.eclipse.equinox.p2.extensionlocation' range='[0.0.0,1.5.700.v20250720-1526)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Extension Location Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.extensionlocation'/>
        <property name='maven-version' value='1.5.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' version='1.5.700.v20250720-1526'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.extensionlocation' version='1.5.700.v20250720-1526'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.extensionlocation' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.extensionlocation' version='1.5.700.v20250720-1526'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.8.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.extensionlocation
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation.source' range='[1.5.700.v20250720-1526,1.5.700.v20250720-1526]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.extensionlocation' version='1.5.700.v20250720-1526'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.extensionlocation;singleton:=true&#xA;Bundle-Version: 1.5.700.v20250720-1526
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.garbagecollector' version='1.3.700.v20250715-0459' generation='2'>
      <update id='org.eclipse.equinox.p2.garbagecollector' range='[0.0.0,1.3.700.v20250715-0459)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Garbage Collector'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.garbagecollector'/>
        <property name='maven-version' value='1.3.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' version='1.3.700.v20250715-0459'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.garbagecollector' version='1.3.700.v20250715-0459'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.garbagecollector' version='1.3.700.v20250715-0459'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.garbagecollector
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector.source' range='[1.3.700.v20250715-0459,1.3.700.v20250715-0459]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.garbagecollector' version='1.3.700.v20250715-0459'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.garbagecollector;singleton:=true&#xA;Bundle-Version: 1.3.700.v20250715-0459
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.3.700.v20260304-1232' generation='2'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.3.700.v20260304-1232)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.jarprocessor'/>
        <property name='maven-version' value='1.3.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.700.v20260304-1232'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.700.v20260304-1232'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.jarprocessor' version='1.3.700.v20260304-1232'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.jarprocessor
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor.source' range='[1.3.700.v20260304-1232,1.3.700.v20260304-1232]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.3.700.v20260304-1232'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.3.700.v20260304-1232
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.9.700.v20260516-0947' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.9.700.v20260516-0947)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata'/>
        <property name='maven-version' value='2.9.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.9.700.v20260516-0947'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.9.700.v20260516-0947'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.internal.p2.metadata.expression,org.eclipse.equinox.p2.metadata.expression' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.internal.p2.metadata,org.eclipse.equinox.p2.metadata.expression' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.p2.metadata.index,org.eclipse.equinox.p2.query,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.p2.metadata.expression,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.internal.p2.metadata.index,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.metadata.expression,org.eclipse.equinox.p2.metadata.index' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata' version='2.9.700.v20260516-0947'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.metadata
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.source' range='[2.9.700.v20260516-0947,2.9.700.v20260516-0947]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.9.700.v20260516-0947'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.9.700.v20260516-0947
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.5.800.v20260304-1232' generation='2'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.5.800.v20260304-1232)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata.repository'/>
        <property name='maven-version' value='1.5.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.800.v20260304-1232'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.800.v20260304-1232'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.metadata.repository' version='1.5.800.v20260304-1232'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.12.600,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.12.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.metadata.repository
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository.source' range='[1.5.800.v20260304-1232,1.5.800.v20260304-1232]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.5.800.v20260304-1232'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.5.800.v20260304-1232
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher' version='1.9.700.v20260512-1529' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher' range='[0.0.0,1.9.700.v20260512-1529)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher Infrastructure'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.publisher'/>
        <property name='maven-version' value='1.9.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' version='1.9.700.v20260512-1529'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher' version='1.9.700.v20260512-1529'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher' version='1.9.700.v20260512-1529'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.8.1,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.checksum' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.publisher
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.source' range='[1.9.700.v20260512-1529,1.9.700.v20260512-1529]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher' version='1.9.700.v20260512-1529'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher;singleton:=true&#xA;Bundle-Version: 1.9.700.v20260512-1529
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher.eclipse' version='1.6.800.v20260304-1232' generation='2'>
      <update id='org.eclipse.equinox.p2.publisher.eclipse' range='[0.0.0,1.6.800.v20260304-1232)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher for Eclipse'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.publisher.eclipse'/>
        <property name='maven-version' value='1.6.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.6.800.v20260304-1232'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.6.800.v20260304-1232'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.build.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.publishing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.swt.tools' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.6.800.v20260304-1232'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='36'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.util' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='[1.2.0,2.0.0]'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.publisher.eclipse
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse.source' range='[1.6.800.v20260304-1232,1.6.800.v20260304-1232]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher.eclipse' version='1.6.800.v20260304-1232'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher.eclipse;singleton:=true&#xA;Bundle-Version: 1.6.800.v20260304-1232
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.reconciler.dropins' version='1.5.800.v20251111-0852' generation='2'>
      <update id='org.eclipse.equinox.p2.reconciler.dropins' range='[0.0.0,1.5.800.v20251111-0852)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Drop-in'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.reconciler.dropins'/>
        <property name='maven-version' value='1.5.800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' version='1.5.800.v20251111-0852'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' version='1.5.800.v20251111-0852'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.reconciler.dropins' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.reconciler.dropins' version='1.5.800.v20251111-0852'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='1.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.extensionlocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.2.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.reconciler.dropins
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins.source' range='[1.5.800.v20251111-0852,1.5.800.v20251111-0852]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.reconciler.dropins' version='1.5.800.v20251111-0852'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.reconciler.dropins;singleton:=true&#xA;Bundle-Version: 1.5.800.v20251111-0852
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.9.700.v20260316-0549' generation='2'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.9.700.v20260316-0549)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.repository'/>
        <property name='maven-version' value='2.9.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.9.700.v20260316-0549'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.9.700.v20260316-0549'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp,org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.repository.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.3.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.query,org.eclipse.equinox.p2.repository' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.metadata.expression,org.eclipse.equinox.p2.repository,org.eclipse.equinox.p2.repository.artifact,org.eclipse.equinox.p2.repository.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.repository' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.repository,org.eclipse.equinox.p2.repository.metadata,org.eclipse.equinox.p2.repository.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.bouncycastle.openpgp,org.eclipse.core.runtime,org.eclipse.equinox.p2.core,org.eclipse.equinox.p2.repository' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.repository' version='2.9.700.v20260316-0549'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='30'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='org.bouncycastle.bcpg' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.gpg.keybox' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.gpg.keybox.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.bc' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.openpgp.operator.jcajce' range='1.72.0'/>
        <required namespace='java.package' name='org.bouncycastle.util.encoders' range='1.72.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.repository
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.source' range='[2.9.700.v20260316-0549,2.9.700.v20260316-0549]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.9.700.v20260316-0549'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.9.700.v20260316-0549
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.4.600.v20250722-0413' generation='2'>
      <update id='org.eclipse.equinox.p2.touchpoint.eclipse' range='[0.0.0,2.4.600.v20250722-0413)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Eclipse Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.touchpoint.eclipse'/>
        <property name='maven-version' value='2.4.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.4.600.v20250722-0413'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.4.600.v20250722-0413'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.update' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.touchpoint.eclipse.query' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.equinox.p2.metadata,org.eclipse.equinox.p2.query' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.4.600.v20250722-0413'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='37'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='[3.0.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.7.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.3.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.p2.touchpoint.eclipse
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse.source' range='[2.4.600.v20250722-0413,2.4.600.v20250722-0413]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.4.600.v20250722-0413'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.eclipse;singleton:=true&#xA;Bundle-Version: 2.4.600.v20250722-0413
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704' generation='2'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.12.100.v20251111-0704)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.12.100-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.6.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime,org.osgi.service.prefs' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.18.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.prefs' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.10.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.preferences
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences.source' range='[3.12.100.v20251111-0704,3.12.100.v20251111-0704]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.12.100.v20251111-0704'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.12.100.v20251111-0704
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651' generation='2'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.12.600.v20250906-0651)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.12.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.7.0'>
          <properties size='3'>
            <property name='java.package.directive.mandatory' value='registry' type='List'/>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime.spi,org.osgi.framework' type='List'/>
            <property name='java.package.attribute.registry' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.core.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.eclipse.core.runtime' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.15.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.9.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.registry
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry.source' range='[3.12.600.v20250906-0651,3.12.600.v20250906-0651]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.12.600.v20250906-0651'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.12.600.v20250906-0651
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.4.700.v20250622-1644' generation='2'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.4.700.v20250622-1644)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.security'/>
        <property name='maven-version' value='1.4.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.4.700.v20250622-1644'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.4.700.v20250622-1644'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth,javax.security.auth.callback,javax.security.auth.login' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto.spec' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.security.auth,javax.security.auth.callback,javax.security.auth.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.crypto.spec,org.eclipse.equinox.security.storage' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.security' version='1.4.700.v20250622-1644'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.security
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.source' range='[1.4.700.v20250622-1644,1.4.700.v20250622-1644]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.4.700.v20250622-1644'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.4.700.v20250622-1644
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.5.700.v20251111-1031)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator'/>
        <property name='maven-version' value='1.5.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='org.eclipse.osgi.container' range='[1.9.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.7.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.resolver' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.source' range='[1.5.700.v20251111-1031,1.5.700.v20251111-1031]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.5.700.v20251111-1031'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.5.700.v20251111-1031
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.700.v20260306-0556' generation='2'>
      <update id='org.eclipse.equinox.simpleconfigurator.manipulator' range='[0.0.0,2.3.700.v20260306-0556)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleName' value='Simple Configurator Manipulator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator.manipulator'/>
        <property name='maven-version' value='2.3.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.700.v20260306-0556'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.700.v20260306-0556'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.700.v20260306-0556'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.6.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.equinox.simpleconfigurator.manipulator
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator.source' range='[2.3.700.v20260306-0556,2.3.700.v20260306-0556]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.3.700.v20260306-0556'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator.manipulator;singleton:=true&#xA;Bundle-Version: 2.3.700.v20260306-0556
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt.core' version='3.46.0.v20260520-1003' generation='2'>
      <update id='org.eclipse.jdt.core' range='[0.0.0,3.46.0.v20260520-1003)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Java Development Tools Core'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.jdt'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.core'/>
        <property name='maven-version' value='3.46.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='41'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' version='3.46.0.v20260520-1003'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jdt.core' version='3.46.0.v20260520-1003'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.compiler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.eval' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.jdom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.codeassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.codeassist.complete' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.codeassist.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.codeassist.select' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.builder' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.dom.rewrite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.dom.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.eval' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.hierarchy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.jdom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.nd.java.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.search.indexing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.search.matching' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.search.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.eval' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.formatter.linewrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.formatter.old' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jdt.core' version='3.46.0.v20260520-1003'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.22.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.11.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.core' range='[3.1.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core.compiler.batch' range='3.46.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.jdt.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.source' range='[3.46.0.v20260520-1003,3.46.0.v20260520-1003]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jdt.core' version='3.46.0.v20260520-1003'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='3'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jdt.core; singleton:=true&#xA;Bundle-Version: 3.46.0.v20260520-1003
          </instruction>
          <instruction key='uninstall'>
            removeJvmArg(jvmArg:-XX:CompileCommand=quiet); removeJvmArg(jvmArg:-XX:CompileCommand=exclude org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer::getExtendedRange);
          </instruction>
          <instruction key='install'>
            addJvmArg(jvmArg:-XX:CompileCommand=quiet); addJvmArg(jvmArg:-XX:CompileCommand=exclude org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer::getExtendedRange);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt.core.compiler.batch' version='3.46.0.v20260528-0407' singleton='false' generation='2'>
      <update id='org.eclipse.jdt.core.compiler.batch' range='[0.0.0,3.46.0.v20260528-0407)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Compiler for Java(TM)'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
        <property name='maven-groupId' value='org.eclipse.jdt'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.core.compiler.batch'/>
        <property name='maven-version' value='3.46.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='25'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.compiler.batch' version='3.46.0.v20260528-0407'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jdt.core.compiler.batch' version='3.46.0.v20260528-0407'/>
        <provided namespace='java.package' name='META-INF.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.compiler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.core.compiler.batch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.antadapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.apt.dispatch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.apt.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.apt.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.ast' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.batch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.classfmt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.codegen' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.env' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.flow' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.lookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.parser.diagnose' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.problem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.tool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.compiler.util' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jdt.core.compiler.batch' version='3.46.0.v20260528-0407'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.jdt.core.compiler.batch
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.compiler.batch.source' range='[3.46.0.v20260528-0407,3.46.0.v20260528-0407]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jdt.core.compiler.batch' version='3.46.0.v20260528-0407'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jdt.core.compiler.batch&#xA;Bundle-Version: 3.46.0.v20260528-0407
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt.debug' version='3.26.0.v20260418-1439' generation='2'>
      <update id='org.eclipse.jdt.debug' range='[0.0.0,3.26.0.v20260418-1439)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='JDI Debug Model'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.jdt'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.debug'/>
        <property name='maven-version' value='3.26.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='23'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug' version='3.26.0.v20260418-1439'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jdt.debug' version='3.26.0.v20260418-1439'/>
        <provided namespace='java.package' name='org.eclipse.jdi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.hcr' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal.connect' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal.jdwp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal.request' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdi.internal.spy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.debug.eval' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.core.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.core.hcr' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.core.logicalstructures' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.eval' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.eval.ast.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.debug.eval.ast.instructions' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jdt.debug' version='3.26.0.v20260418-1439'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.19.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.22.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core' range='[3.40.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.9.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.jdt.debug
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug.source' range='[3.26.0.v20260418-1439,3.26.0.v20260418-1439]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jdt.debug' version='3.26.0.v20260418-1439'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jdt.debug; singleton:=true&#xA;Bundle-Version: 3.26.0.v20260418-1439
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt.launching' version='3.24.200.v20260408-0443' generation='2'>
      <update id='org.eclipse.jdt.launching' range='[0.0.0,3.24.200.v20260408-0443)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Java Development Tools Launching Support'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.jdt'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.launching'/>
        <property name='maven-version' value='3.24.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching' version='3.24.200.v20260408-0443'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jdt.launching' version='3.24.200.v20260408-0443'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.launching' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.launching.environments' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.internal.launching.sourcelookup.advanced' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.launching' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.launching.environments' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.launching.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.launching.sourcelookup.advanced' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jdt.launching.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jdt.launching' version='3.24.200.v20260408-0443'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.30.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core' range='[3.43.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.jdt.launching
          </description>
        </requiredProperties>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.8.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.22.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.source' range='[3.24.200.v20260408-0443,3.24.200.v20260408-0443]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.macosx' range='0.0.0'>
          <filter>
            (&amp;(osgi.os=macosx)(!(org.eclipse.jdt.buildtime=true)))
          </filter>
        </required>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.14.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.debug' range='[3.21.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jdt.launching' version='3.24.200.v20260408-0443'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jdt.launching; singleton:=true&#xA;Bundle-Version: 3.24.200.v20260408-0443
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jetty.servlet-api' version='4.0.9' singleton='false' generation='2'>
      <update id='org.eclipse.jetty.servlet-api' range='[0.0.0,4.0.9)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Jetty Servlet API and Schemas for JPMS and OSGi'/>
        <property name='org.eclipse.equinox.p2.description' value='Combined servlet api and schemas for use in JPMS and OSGi environments'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://eclipse.org/jetty'/>
        <property name='maven-groupId' value='org.eclipse.jetty.toolchain'/>
        <property name='maven-artifactId' value='jetty-servlet-api'/>
        <property name='maven-version' value='4.0.9'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.servlet-api' version='4.0.9'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jetty.servlet-api' version='4.0.9'/>
        <provided namespace='java.package' name='javax.servlet' version='4.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet.annotation,javax.servlet.descriptor' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='javax.servlet.resources' version='4.0.0'/>
        <provided namespace='java.package' name='javax.servlet.annotation' version='4.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='javax.servlet.http' version='4.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='javax.servlet.descriptor' version='4.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.resources' version='4.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.jetty.servlet-api' version='4.0.9'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='java.package' name='java.io' range='0.0.0'/>
        <required namespace='java.package' name='java.lang' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.annotation' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.invoke' range='0.0.0'/>
        <required namespace='java.package' name='java.lang.reflect' range='0.0.0'/>
        <required namespace='java.package' name='java.net' range='0.0.0'/>
        <required namespace='java.package' name='java.security' range='0.0.0'/>
        <required namespace='java.package' name='java.text' range='0.0.0'/>
        <required namespace='java.package' name='java.util' range='0.0.0'/>
        <required namespace='java.package' name='java.util.function' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.jetty.servlet-api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=11))'>
          <description>
            org.eclipse.jetty.servlet-api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.servlet-api.source' range='[4.0.9,4.0.9]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jetty.servlet-api' version='4.0.9'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jetty.servlet-api&#xA;Bundle-Version: 4.0.9
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.24.200.v20260515-1403' generation='2'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.24.200.v20260515-1403)' severity='0'/>
      <properties size='11'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.24.200-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='97'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.24.200.v20260515-1403'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.24.200.v20260515-1403'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.service.log' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.9.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.osgi.report.resolution,org.osgi.framework.wiring,org.eclipse.osgi.framework.eventmgr,org.osgi.framework.startlevel,org.osgi.framework,org.osgi.framework.hooks.resolver,org.osgi.service.resolver,org.osgi.resource,org.eclipse.osgi.service.debug' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.osgi.util,org.eclipse.osgi.container' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.framework.launch,org.osgi.framework.connect' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.resolver,org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.4.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.7.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.framework.hooks.resolver,org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.10.0'/>
        <provided namespace='java.package' name='org.osgi.framework.connect' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.launch' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework.wiring' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.3.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto,org.osgi.resource.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.condition' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.log.admin' version='1.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.log' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.resource' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.4'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.osgi' version='3.24.200.v20260515-1403'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-1' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LogReaderService,org.eclipse.equinox.log.ExtendedLogReaderService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-2' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.LoggerFactory,org.osgi.service.log.LogService,org.eclipse.equinox.log.ExtendedLogService' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-3' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.log.admin.LoggerAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-4' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.framework.log.FrameworkLog' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-5' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.user.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-6' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.instance.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-7' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.configuration.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-8' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='osgi.install.area'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-9' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.eclipse.osgi.service.datalocation.Location' type='List'/>
            <property name='type' value='eclipse.home.location'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-10' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.environment.EnvironmentInfo' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-11' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.packageadmin.PackageAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-12' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.startlevel.StartLevel' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-13' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.permissionadmin.PermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-14' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.condpermadmin.ConditionalPermissionAdmin' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-15' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.osgi.service.resolver.Resolver' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-16' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.debug.DebugOptions' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-17' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.urlconversion.URLConverter' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-18' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.localization.BundleLocalization' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-19' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.service.security.TrustEngine' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-20' version='0.0.0'>
          <properties size='1'>
            <property name='objectClass' value='org.eclipse.osgi.signedcontent.SignedContentFactory' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='org.eclipse.osgi_3.24.200.v20260515-1403-21' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.osgi.service.condition.Condition' type='List'/>
            <property name='osgi.condition.id' value='true'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.connect.ConnectFrameworkFactory' version='0.0.0'/>
        <provided namespace='osgi.serviceloader' name='org.osgi.framework.launch.FrameworkFactory' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(version=1.8)(|(osgi.ee=JavaSE)(osgi.ee=JavaSE/compact1)))'>
          <description>
            org.eclipse.osgi
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.source' range='[3.24.200.v20260515-1403,3.24.200.v20260515-1403]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.24.200.v20260515-1403'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.24.200.v20260515-1403
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.12.300.v20250707-1221' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.12.300.v20250707-1221)' severity='0'/>
      <properties size='13'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.services'/>
        <property name='maven-version' value='3.12.300-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.12.300.v20250707-1221'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.12.300.v20250707-1221'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.5.0'>
          <properties size='2'>
            <property name='java.package.attribute.never.ever.use' value='true'/>
            <property name='java.package.directive.mandatory' value='never.ever.use' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.services' version='3.12.300.v20250707-1221'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.http.whiteboard' range='[1.1.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.event' range='[1.4.0,1.5.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.service.api' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.services
          </description>
        </requiredProperties>
        <required namespace='osgi.bundle' name='org.osgi.service.component' range='[1.5.0,1.6.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services.source' range='[3.12.300.v20250707-1221,3.12.300.v20250707-1221]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
        <required namespace='osgi.bundle' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.metatype' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.5.0,1.6.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.service.cm' range='[1.6.0,1.7.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.12.300.v20250707-1221'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services;deprecated:=&quot;Deprecated in favour of the original jars published by the OSGi working-group.&quot;&#xA;Bundle-Version: 3.12.300.v20250707-1221
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.7.400.v20250516-0916' singleton='false' generation='2'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.7.400.v20250516-0916)' severity='0'/>
      <properties size='13'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.util'/>
        <property name='maven-version' value='3.7.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
        <provided namespace='osgi.identity' name='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.osgi.util.function' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.promise' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.position' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.osgi.util.xml' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.eclipse.osgi.util
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util.source' range='[3.7.400.v20250516-0916,3.7.400.v20250516-0916]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.7.400.v20250516-0916'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.7.400.v20250516-0916
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.text' version='3.14.700.v20260326-1107' singleton='false' generation='2'>
      <update id='org.eclipse.text' range='[0.0.0,3.14.700.v20260326-1107)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.pluginName' value='Text'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.text'/>
        <property name='maven-version' value='3.14.700-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' version='3.14.700.v20260326-1107'/>
        <provided namespace='osgi.bundle' name='org.eclipse.text' version='3.14.700.v20260326-1107'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.directive.mandatory' value='text' type='List'/>
            <property name='java.package.attribute.text' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.directive.mandatory' value='text' type='List'/>
            <property name='java.package.attribute.text' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.jface.text.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.rules' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.directive.mandatory' value='text' type='List'/>
            <property name='java.package.attribute.text' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.directive.mandatory' value='text' type='List'/>
            <property name='java.package.attribute.text' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'>
          <properties size='2'>
            <property name='java.package.directive.mandatory' value='text' type='List'/>
            <property name='java.package.attribute.text' value='split'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.text.edits' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.readers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.undo' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.eclipse.text' version='3.14.700.v20260326-1107'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.29.0,4.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=17))'>
          <description>
            org.eclipse.text
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text.source' range='[3.14.700.v20260326-1107,3.14.700.v20260326-1107]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.text' version='3.14.700.v20260326-1107'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.text&#xA;Bundle-Version: 3.14.700.v20260326-1107
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205' singleton='false' generation='2'>
      <update id='org.eclipse.xtend.lib' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtend Runtime Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtend.lib'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.declaration,org.eclipse.xtend.lib.macro' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.annotations' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.declaration,org.eclipse.xtend2.lib,org.eclipse.xtend.lib.macro' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' range='2.43.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtend.lib
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtend.lib' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtend.lib&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205' singleton='false' generation='2'>
      <update id='org.eclipse.xtend.lib.macro' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtend Macro Interfaces'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtend.lib.macro'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.file,org.eclipse.xtend.lib.macro.services,org.eclipse.xtend.lib.macro.declaration' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.macro.declaration' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.file,org.eclipse.xtend2.lib,org.eclipse.xtend.lib.macro.expression,org.eclipse.xtext.xbase.lib' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.macro.expression' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.declaration' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.macro.file' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtend.lib.macro.services' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtend.lib.macro.declaration,org.eclipse.xtext.xbase.lib' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.43.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtend.lib.macro
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtend.lib.macro.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtend.lib.macro' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtend.lib.macro&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext' version='2.43.0.v20260525-1205' generation='2'>
      <update id='org.eclipse.xtext' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='72'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.build' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.services' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.conversion' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.conversion.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.debug' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.diagnostics' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.documentation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.documentation.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.findReferences' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting2' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting2.debug' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting2.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting2.regionaccess' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.formatting2.regionaccess.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.generator' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.generator.trace' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.generator.trace.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.generator.trace.node' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.grammaranalysis' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.grammaranalysis.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.linking' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.linking.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.linking.lazy' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.mwe' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.naming' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.nodemodel' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.nodemodel.detachable' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.nodemodel.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.nodemodel.serialization' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.nodemodel.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parser' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parser.antlr' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parser.antlr.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parser.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parsetree.reconstr' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.parsetree.reconstr.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.preferences' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource.clustering' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource.containers' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource.generic' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.resource.persistence' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.scoping' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.scoping.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.acceptor' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.analysis' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.diagnostic' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.sequencer' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.serializer.tokens' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.service' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.services' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.tasks' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.validation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.validation.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.workspace' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtext' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtext.ecoreInference' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtext.parser' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.xmi' range='2.37.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.36.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='2.30.0'/>
        <required namespace='osgi.bundle' name='org.antlr.runtime' range='[3.2.0,3.2.1)'/>
        <required namespace='osgi.bundle' name='org.objectweb.asm' range='[9.9.1,10.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.mwe.core' range='1.19.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.mwe.utils' range='1.19.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.util' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.100' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.20.300'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext;singleton:=true&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205' singleton='false' generation='2'>
      <update id='org.eclipse.xtext.builder.standalone' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext Standalone Builder'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.builder.standalone'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.builder.standalone.compiler' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.builder.standalone.incremental' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.common.types' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jdt.core' range='3.44.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.36.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.20.300'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.builder.standalone
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.builder.standalone.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.builder.standalone' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.builder.standalone&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205' generation='2'>
      <update id='org.eclipse.xtext.common.types' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext Common Types'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.common.types'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.access' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.access.binary' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.access.binary.asm' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.access.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.access.reflect' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.descriptions' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.common.types.xtext' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.36.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='2.30.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.objectweb.asm' range='[9.9.1,10.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='java.package' name='io.github.classgraph' range='[4.8.184,4.9.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='1.0.4' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.common.types
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.common.types.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.common.types' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.common.types;singleton:=true&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205' generation='2'>
      <update id='org.eclipse.xtext.ecore' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext Ecore Support'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.ecore'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.emf.ecore,com.google.inject,org.eclipse.xtext.resource.generic,org.eclipse.xtext.resource.impl,org.eclipse.xtext.naming,org.eclipse.xtext.util,org.eclipse.xtext' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='2.43.0'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.ecore
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ecore.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.ecore' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.ecore;singleton:=true&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205' generation='2'>
      <update id='org.eclipse.xtext.ide' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext IDE Core'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.ide'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='38'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.bracketmatching' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.contentassist' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.contentassist.antlr' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.contentassist.antlr.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.folding' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.hierarchy' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.model' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.navigation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.partialEditing' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.quickfix' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.editor.syntaxcoloring' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.labels' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.refactoring' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.serializer' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.serializer.debug' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.serializer.hooks' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.serializer.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.codeActions' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.codelens' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.commands' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.concurrent' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.contentassist' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.findReferences' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.folding' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.formatting' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.hover' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.occurrences' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.rename' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.semantictokens' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.signatureHelp' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.server.symbol' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.ide.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.util' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.100' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.20.300'/>
        <required namespace='osgi.bundle' name='org.eclipse.lsp4j' range='[1.0.0,1.1.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.lsp4j.jsonrpc' range='[1.0.0,1.1.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore.change' range='2.16.0'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.ide
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.ide.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.ide' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.ide;singleton:=true&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.util' version='2.43.0.v20260525-1205' singleton='false' generation='2'>
      <update id='org.eclipse.xtext.util' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xtext Utility'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.util'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.emf.ecore.resource,org.apache.log4j,org.eclipse.emf.common.util,com.google.common.base,org.eclipse.emf.common.notify,org.eclipse.xtext.util.concurrent,org.eclipse.emf.ecore.util,org.eclipse.emf.ecore,com.google.inject' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtext.util.concurrent' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.eclipse.xtext.util' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.eclipse.xtext.util.formallang' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.util.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.36.0'/>
        <required namespace='osgi.bundle' name='com.google.guava' range='[33.6.0,34.0.0)'/>
        <required namespace='osgi.bundle' name='com.google.inject' range='7.0.0'/>
        <required namespace='osgi.bundle' name='com.google.guava.failureaccess' range='[1.0.3,2.0.0)'/>
        <required namespace='osgi.bundle' name='jakarta.inject.jakarta.inject-api' range='2.0.1' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.util
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.util.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.util' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.util&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205' generation='2'>
      <update id='org.eclipse.xtext.xbase' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xbase Model'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.xbase'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='57'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.formatting' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.formatting2' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.parser.antlr' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.parser.antlr.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.serializer' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.services' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.typesystem' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.typing' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.validation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.xAnnotations' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.xAnnotations.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.annotations.xAnnotations.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.compiler' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.compiler.output' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.controlflow' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.conversion' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.debug' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.featurecalls' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.formatting' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.formatting2' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.imports' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.interpreter' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.interpreter.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.jvmmodel' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.linking' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.parser' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.parser.antlr' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.parser.antlr.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.resource' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.scoping' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.scoping.batch' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.scoping.featurecalls' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.serializer' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.services' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.arguments' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.computation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.conformance' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.internal.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.legacy' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.override' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.references' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typesystem.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.typing' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.validation' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtype' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtype.impl' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xtype.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.xtext' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.common.types' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.ecore' range='2.36.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.emf.common' range='2.30.0'/>
        <required namespace='osgi.bundle' name='org.antlr.runtime' range='[3.2.0,3.2.1)'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.xtend.lib' range='2.43.0'/>
        <required namespace='osgi.bundle' name='org.objectweb.asm' range='[9.9.1,10.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.log4j' range='1.2.26'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.xbase
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.xbase' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.xbase;singleton:=true&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205' singleton='false' generation='2'>
      <update id='org.eclipse.xtext.xbase.lib' range='[0.0.0,2.43.0.v20260525-1205)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Xbase Runtime Library'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Xtext'/>
        <property name='maven-groupId' value='org.eclipse.xtext'/>
        <property name='maven-artifactId' value='org.eclipse.xtext.xbase.lib'/>
        <property name='maven-version' value='2.43.0'/>
        <property name='maven-type' value='eclipse-plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.bundle' name='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtend2.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.lib.internal' version='2.43.0.v20260525-1205'/>
        <provided namespace='java.package' name='org.eclipse.xtext.xbase.lib.util' version='2.43.0.v20260525-1205'/>
        <provided namespace='osgi.identity' name='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='com.google.guava' range='[33.6.0,34.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=21))'>
          <description>
            org.eclipse.xtext.xbase.lib
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xtext.xbase.lib.source' range='[2.43.0.v20260525-1205,2.43.0.v20260525-1205]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.xtext.xbase.lib' version='2.43.0.v20260525-1205'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.xtext.xbase.lib&#xA;Bundle-Version: 2.43.0.v20260525-1205
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.hamcrest' version='3.0.0' singleton='false' generation='2'>
      <update id='org.hamcrest' range='[0.0.0,3.0.0)' severity='0'/>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='org.hamcrest'/>
        <property name='maven-groupId' value='org.hamcrest'/>
        <property name='maven-artifactId' value='hamcrest'/>
        <property name='maven-version' value='3.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest' version='3.0.0'/>
        <provided namespace='osgi.bundle' name='org.hamcrest' version='3.0.0'/>
        <provided namespace='java.package' name='org.hamcrest' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,org.hamcrest.collection,org.hamcrest.core,org.hamcrest.internal,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.beans' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.collection' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.comparator' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.core' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.internal' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.io' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.number' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.object' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.text' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.hamcrest' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.hamcrest.xml' version='3.0.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.namespace,org.hamcrest,org.w3c.dom' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.hamcrest' version='3.0.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='java.package' name='javax.xml.namespace' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.xml.xpath' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.hamcrest' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.beans' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.collection' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.comparator' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.core' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.internal' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.number' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.object' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.text' range='0.0.0'/>
        <required namespace='java.package' name='org.hamcrest.xml' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            org.hamcrest
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.source' range='[3.0.0,3.0.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.hamcrest' version='3.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.hamcrest&#xA;Bundle-Version: 3.0.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.junit' version='4.13.2.v20240929-1000' singleton='false' generation='2'>
      <update id='org.junit' range='[0.0.0,4.13.2.v20240929-1000)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Bundle junit : junit'/>
        <property name='maven-wrapped-groupId' value='junit'/>
        <property name='maven-wrapped-artifactId' value='junit'/>
        <property name='maven-wrapped-version' value='4.13.2'/>
        <property name='maven-wrapped-classifier' value=''/>
      </properties>
      <provides size='36'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.junit' version='4.13.2.v20240929-1000'/>
        <provided namespace='osgi.bundle' name='org.junit' version='4.13.2.v20240929-1000'/>
        <provided namespace='java.package' name='org.junit.experimental.theories.internal' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.experimental.theories,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.notification' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.builders' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.notification,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.management' version='4.13.2'/>
        <provided namespace='java.package' name='org.junit.internal.matchers' version='4.13.2'/>
        <provided namespace='java.package' name='org.junit.internal.requests' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.manipulation' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.runners' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='junit.framework,org.junit.runner,org.junit.runner.manipulation,org.junit.runner.notification' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.runners.model' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.internal,org.junit.runner,org.junit.runner.notification,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.runners.rules' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.internal.runners.statements' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='junit.extensions' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='junit.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='junit.framework' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.manipulation,org.junit.runner.notification' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='junit.runner' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='junit.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='junit.textui' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='junit.framework,junit.runner' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.function,org.junit.internal,org.junit.runners' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.categories' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.manipulation,org.junit.runners,org.junit.runners.model,org.junit.validator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.max' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.notification' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.results' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.notification' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.runners' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runners,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.theories' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.experimental.theories.internal,org.junit.internal,org.junit.runners,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.experimental.theories.suppliers' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.experimental.theories' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.function' version='4.13.2'/>
        <provided namespace='java.package' name='org.junit.matchers' version='4.13.2'/>
        <provided namespace='java.package' name='org.junit.rules' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit,org.junit.function,org.junit.internal,org.junit.runner,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runner' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='junit.framework,org.junit.runner.manipulation,org.junit.runner.notification,org.junit.runners.model,org.junit.validator' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runner.manipulation' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runner.notification' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runners' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.internal.runners,org.junit.rules,org.junit.runner,org.junit.runner.manipulation,org.junit.runner.notification,org.junit.runners.model,org.junit.runners.parameterized' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runners.model' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.runners.parameterized' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runner,org.junit.runner.notification,org.junit.runners,org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.junit.validator' version='4.13.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.junit.runners.model' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.junit' version='4.13.2.v20240929-1000'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.hamcrest' range='2.2.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.junit
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit.source' range='[4.13.2.v20240929-1000,4.13.2.v20240929-1000]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.junit' version='4.13.2.v20240929-1000'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.junit&#xA;Bundle-Version: 4.13.2.v20240929-1000
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.objectweb.asm' version='9.9.1' singleton='false' generation='2'>
      <update id='org.objectweb.asm' range='[0.0.0,9.9.1)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='org.objectweb.asm'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://asm.ow2.org'/>
        <property name='maven-groupId' value='org.ow2.asm'/>
        <property name='maven-artifactId' value='asm'/>
        <property name='maven-version' value='9.9.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm' version='9.9.1'/>
        <provided namespace='osgi.bundle' name='org.objectweb.asm' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm.signature' version='9.9.1'/>
        <provided namespace='osgi.identity' name='org.objectweb.asm' version='9.9.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.objectweb.asm
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.source' range='[9.9.1,9.9.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.objectweb.asm' version='9.9.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.objectweb.asm&#xA;Bundle-Version: 9.9.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.objectweb.asm.commons' version='9.9.1' singleton='false' generation='2'>
      <update id='org.objectweb.asm.commons' range='[0.0.0,9.9.1)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='org.objectweb.asm.commons'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://asm.ow2.org'/>
        <property name='maven-groupId' value='org.ow2.asm'/>
        <property name='maven-artifactId' value='asm-commons'/>
        <property name='maven-version' value='9.9.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.commons' version='9.9.1'/>
        <provided namespace='osgi.bundle' name='org.objectweb.asm.commons' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm.commons' version='9.9.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.objectweb.asm,org.objectweb.asm.signature,org.objectweb.asm.tree' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.objectweb.asm.commons' version='9.9.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='org.objectweb.asm' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.signature' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.tree' range='[9.9.1,9.10.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.objectweb.asm.commons
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.commons.source' range='[9.9.1,9.9.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.objectweb.asm.commons' version='9.9.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.objectweb.asm.commons&#xA;Bundle-Version: 9.9.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.objectweb.asm.tree' version='9.9.1' singleton='false' generation='2'>
      <update id='org.objectweb.asm.tree' range='[0.0.0,9.9.1)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='org.objectweb.asm.tree'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://asm.ow2.org'/>
        <property name='maven-groupId' value='org.ow2.asm'/>
        <property name='maven-artifactId' value='asm-tree'/>
        <property name='maven-version' value='9.9.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree' version='9.9.1'/>
        <provided namespace='osgi.bundle' name='org.objectweb.asm.tree' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm.tree' version='9.9.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.objectweb.asm,org.objectweb.asm.signature' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.objectweb.asm.tree' version='9.9.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.objectweb.asm' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.signature' range='[9.9.1,9.10.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.objectweb.asm.tree
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree.source' range='[9.9.1,9.9.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.objectweb.asm.tree' version='9.9.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.objectweb.asm.tree&#xA;Bundle-Version: 9.9.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.objectweb.asm.tree.analysis' version='9.9.1' singleton='false' generation='2'>
      <update id='org.objectweb.asm.tree.analysis' range='[0.0.0,9.9.1)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='org.objectweb.asm.tree.analysis'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://asm.ow2.org'/>
        <property name='maven-groupId' value='org.ow2.asm'/>
        <property name='maven-artifactId' value='asm-analysis'/>
        <property name='maven-version' value='9.9.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree.analysis' version='9.9.1'/>
        <provided namespace='osgi.bundle' name='org.objectweb.asm.tree.analysis' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm.tree.analysis' version='9.9.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.objectweb.asm,org.objectweb.asm.signature,org.objectweb.asm.tree' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.objectweb.asm.tree.analysis' version='9.9.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='org.objectweb.asm' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.signature' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.tree' range='[9.9.1,9.10.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.objectweb.asm.tree.analysis
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree.analysis.source' range='[9.9.1,9.9.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.objectweb.asm.tree.analysis' version='9.9.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.objectweb.asm.tree.analysis&#xA;Bundle-Version: 9.9.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.objectweb.asm.util' version='9.9.1' singleton='false' generation='2'>
      <update id='org.objectweb.asm.util' range='[0.0.0,9.9.1)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='org.objectweb.asm.util'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://asm.ow2.org'/>
        <property name='maven-groupId' value='org.ow2.asm'/>
        <property name='maven-artifactId' value='asm-util'/>
        <property name='maven-version' value='9.9.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.util' version='9.9.1'/>
        <provided namespace='osgi.bundle' name='org.objectweb.asm.util' version='9.9.1'/>
        <provided namespace='java.package' name='org.objectweb.asm.util' version='9.9.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.objectweb.asm,org.objectweb.asm.signature,org.objectweb.asm.tree,org.objectweb.asm.tree.analysis' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.objectweb.asm.util' version='9.9.1'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.objectweb.asm' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.signature' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.tree' range='[9.9.1,9.10.0)'/>
        <required namespace='java.package' name='org.objectweb.asm.tree.analysis' range='[9.9.1,9.10.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.objectweb.asm.util
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.util.source' range='[9.9.1,9.9.1]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.objectweb.asm.util' version='9.9.1'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.objectweb.asm.util&#xA;Bundle-Version: 9.9.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.cm' version='1.6.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.cm' range='[0.0.0,1.6.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.cm'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.cm Version 1.6.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.cm'/>
        <property name='maven-version' value='1.6.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.cm' version='1.6.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.6.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.cm.annotations' version='1.6.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.cm' version='1.6.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.cm
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.cm.source' range='[1.6.1.202109301733,1.6.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.cm' version='1.6.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.cm&#xA;Bundle-Version: 1.6.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.component' version='1.5.1.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.service.component' range='[0.0.0,1.5.1.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.component'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.component Version 1.5.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.component'/>
        <property name='maven-version' value='1.5.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.component' version='1.5.1.202212101352'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.5.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.component.propertytypes' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework,org.osgi.service.component.runtime.dto,org.osgi.util.promise' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.5.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto,org.osgi.framework.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.component' version='1.5.1.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.component
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component.source' range='[1.5.1.202212101352,1.5.1.202212101352]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.component' version='1.5.1.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.component&#xA;Bundle-Version: 1.5.1.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.device' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.device' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.device'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.device Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.device'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.device' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.device' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.device
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.device.source' range='[1.1.1.202109301733,1.1.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.device' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.device&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.event' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.event' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.event'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.event Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.event'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.event' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.4.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.event.annotations' version='1.4.1'/>
        <provided namespace='java.package' name='org.osgi.service.event.propertytypes' version='1.4.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.event' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.event
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.event.source' range='[1.4.1.202109301733,1.4.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.event' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.event&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.http.whiteboard' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.http.whiteboard' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.http.whiteboard'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.http.whiteboard Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.http.whiteboard'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet.http,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.service.http.runtime.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.dto,org.osgi.framework.dto' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard.annotations' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard.propertytypes' version='1.1.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.servlet' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='javax.servlet' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.http.runtime.dto' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.contract' match='(&amp;(osgi.contract=JavaServlet)(version=3.1.0))'>
          <description>
            org.osgi.service.http.whiteboard
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.http.whiteboard
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.http.whiteboard.source' range='[1.1.1.202109301733,1.1.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.http.whiteboard' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.http.whiteboard&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.metatype' version='1.4.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.metatype' range='[0.0.0,1.4.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.metatype'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.metatype Version 1.4.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.metatype'/>
        <property name='maven-version' value='1.4.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.metatype' version='1.4.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.4.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.metatype' version='1.4.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.metatype
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype.source' range='[1.4.1.202109301733,1.4.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.metatype' version='1.4.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.metatype&#xA;Bundle-Version: 1.4.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.prefs' version='1.1.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.prefs' range='[0.0.0,1.1.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.prefs'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.prefs Version 1.1.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.prefs'/>
        <property name='maven-version' value='1.1.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.prefs' version='1.1.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.2'/>
        <provided namespace='osgi.identity' name='org.osgi.service.prefs' version='1.1.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.prefs
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.prefs.source' range='[1.1.2.202109301733,1.1.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.prefs' version='1.1.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.prefs&#xA;Bundle-Version: 1.1.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.provisioning' version='1.2.0.201505202024' singleton='false' generation='2'>
      <update id='org.osgi.service.provisioning' range='[0.0.0,1.2.0.201505202024)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.provisioning'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.provisioning Version 1.2.0.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.provisioning'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.service.provisioning' version='1.2.0.201505202024'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.service.provisioning
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.provisioning.source' range='[1.2.0.201505202024,1.2.0.201505202024]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.provisioning' version='1.2.0.201505202024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.provisioning&#xA;Bundle-Version: 1.2.0.201505202024
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.upnp' version='1.2.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.upnp' range='[0.0.0,1.2.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.upnp'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.upnp Version 1.2.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.upnp'/>
        <property name='maven-version' value='1.2.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.upnp' version='1.2.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.1'/>
        <provided namespace='osgi.identity' name='org.osgi.service.upnp' version='1.2.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.upnp
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.upnp.source' range='[1.2.1.202109301733,1.2.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.upnp' version='1.2.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.upnp&#xA;Bundle-Version: 1.2.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.useradmin' version='1.1.1.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.useradmin' range='[0.0.0,1.1.1.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.useradmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.useradmin Version 1.1.1'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.useradmin'/>
        <property name='maven-version' value='1.1.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.useradmin' version='1.1.1.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.useradmin
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.useradmin.source' range='[1.1.1.202109301733,1.1.1.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.useradmin' version='1.1.1.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.useradmin&#xA;Bundle-Version: 1.1.1.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.service.wireadmin' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.service.wireadmin' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.service.wireadmin'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.service.wireadmin Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.service.wireadmin'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.service.wireadmin' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.service.wireadmin
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.wireadmin.source' range='[1.0.2.202109301733,1.0.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.service.wireadmin' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.service.wireadmin&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.function' version='1.2.0.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.function' range='[0.0.0,1.2.0.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.function'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.function Version 1.2.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.function'/>
        <property name='maven-version' value='1.2.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.function' version='1.2.0.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.2.0'/>
        <provided namespace='osgi.identity' name='org.osgi.util.function' version='1.2.0.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.function
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.function.source' range='[1.2.0.202109301733,1.2.0.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.function' version='1.2.0.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.function&#xA;Bundle-Version: 1.2.0.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.measurement' version='1.0.2.201802012109' singleton='false' generation='2'>
      <update id='org.osgi.util.measurement' range='[0.0.0,1.0.2.201802012109)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.measurement'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.measurement Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance https://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.measurement'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.measurement' version='1.0.2.201802012109'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.2'/>
        <provided namespace='osgi.identity' name='org.osgi.util.measurement' version='1.0.2.201802012109'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.7))'>
          <description>
            org.osgi.util.measurement
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.measurement.source' range='[1.0.2.201802012109,1.0.2.201802012109]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.measurement' version='1.0.2.201802012109'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.measurement&#xA;Bundle-Version: 1.0.2.201802012109
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.position' version='1.0.1.201505202026' singleton='false' generation='2'>
      <update id='org.osgi.util.position' range='[0.0.0,1.0.1.201505202026)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.position'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.position Version 1.0.1.'/>
        <property name='org.eclipse.equinox.p2.provider' value='OSGi Alliance http://www.osgi.org/'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.position'/>
        <property name='maven-version' value='1.0.1'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.position' version='1.0.1.201505202026'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.util.measurement' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.position' version='1.0.1.201505202026'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.2))'>
          <description>
            org.osgi.util.position
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.position.source' range='[1.0.1.201505202026,1.0.1.201505202026]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.position' version='1.0.1.201505202026'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.position&#xA;Bundle-Version: 1.0.1.201505202026
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.promise' version='1.3.0.202212101352' singleton='false' generation='2'>
      <update id='org.osgi.util.promise' range='[0.0.0,1.3.0.202212101352)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.promise'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.promise Version 1.3.0'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.promise'/>
        <property name='maven-version' value='1.3.0'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.promise' version='1.3.0.202212101352'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.3.0'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.osgi.util.function' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.promise' version='1.3.0.202212101352'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.1.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.promise
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.promise.source' range='[1.3.0.202212101352,1.3.0.202212101352]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.promise' version='1.3.0.202212101352'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.promise&#xA;Bundle-Version: 1.3.0.202212101352
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.osgi.util.xml' version='1.0.2.202109301733' singleton='false' generation='2'>
      <update id='org.osgi.util.xml' range='[0.0.0,1.0.2.202109301733)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='org.osgi:org.osgi.util.xml'/>
        <property name='org.eclipse.equinox.p2.description' value='OSGi Companion Code for org.osgi.util.xml Version 1.0.2'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Foundation'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://docs.osgi.org/'/>
        <property name='maven-groupId' value='org.osgi'/>
        <property name='maven-artifactId' value='org.osgi.util.xml'/>
        <property name='maven-version' value='1.0.2'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='osgi.bundle' name='org.osgi.util.xml' version='1.0.2.202109301733'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.2'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='javax.xml.parsers,org.osgi.framework' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='org.osgi.util.xml' version='1.0.2.202109301733'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE/compact1)(version=1.8))'>
          <description>
            org.osgi.util.xml
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.util.xml.source' range='[1.0.2.202109301733,1.0.2.202109301733]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.osgi.util.xml' version='1.0.2.202109301733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.osgi.util.xml&#xA;Bundle-Version: 1.0.2.202109301733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.6.v20201214' singleton='false' generation='2'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.6.v20201214)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.ow2.sat4j'/>
        <property name='maven-artifactId' value='org.ow2.sat4j.core'/>
        <property name='maven-version' value='2.3.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools.encoding' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.6.v20201214'/>
        <provided namespace='osgi.identity' name='org.sat4j.core' version='2.3.6.v20201214'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.core
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core.source' range='[2.3.6.v20201214,2.3.6.v20201214]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.6.v20201214'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.6.v20201214
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.6.v20201214' singleton='false' generation='2'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.6.v20201214)' severity='0'/>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.ow2.sat4j'/>
        <property name='maven-artifactId' value='org.ow2.sat4j.pb'/>
        <property name='maven-version' value='2.3.6'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.6.v20201214'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.6.v20201214'/>
        <provided namespace='osgi.identity' name='org.sat4j.pb' version='2.3.6.v20201214'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.5))'>
          <description>
            org.sat4j.pb
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb.source' range='[2.3.6.v20201214,2.3.6.v20201214]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.6.v20201214'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.6.v20201214
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.tukaani.xz' version='1.12.0' singleton='false'>
      <update id='org.tukaani.xz' range='[0.0.0,1.12.0)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='XZ data compression'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='https://tukaani.org/xz/xz-javadoc/'/>
        <property name='maven-groupId' value='org.tukaani'/>
        <property name='maven-artifactId' value='xz'/>
        <property name='maven-version' value='1.12'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' version='1.12.0'/>
        <provided namespace='osgi.bundle' name='org.tukaani.xz' version='1.12.0'/>
        <provided namespace='java.package' name='org.tukaani.xz' version='0.0.0'/>
        <provided namespace='osgi.identity' name='org.tukaani.xz' version='1.12.0'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz.source' range='[1.12.0,1.12.0]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.tukaani.xz' version='1.12.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.tukaani.xz&#xA;Bundle-Version: 1.12
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='slf4j.api' version='2.0.18' singleton='false' generation='2'>
      <update id='slf4j.api' range='[0.0.0,2.0.18)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='SLF4J API Module'/>
        <property name='org.eclipse.equinox.p2.description' value='The slf4j API'/>
        <property name='org.eclipse.equinox.p2.provider' value='SLF4J.ORG'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.slf4j.org'/>
        <property name='maven-groupId' value='org.slf4j'/>
        <property name='maven-artifactId' value='slf4j-api'/>
        <property name='maven-version' value='2.0.18'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='slf4j.api' version='2.0.18'/>
        <provided namespace='osgi.bundle' name='slf4j.api' version='2.0.18'/>
        <provided namespace='java.package' name='org.slf4j' version='2.0.18'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.slf4j.event,org.slf4j.helpers,org.slf4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.slf4j.event' version='2.0.18'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.slf4j,org.slf4j.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.slf4j.helpers' version='2.0.18'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.slf4j,org.slf4j.event,org.slf4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.slf4j.spi' version='2.0.18'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.slf4j,org.slf4j.event,org.slf4j.helpers' type='List'/>
          </properties>
        </provided>
        <provided namespace='java.package' name='org.slf4j' version='1.7.36'/>
        <provided namespace='java.package' name='org.slf4j.helpers' version='1.7.36'/>
        <provided namespace='osgi.identity' name='slf4j.api' version='2.0.18'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='org.slf4j.spi' range='[2.0.18,3.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.processor)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            slf4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.serviceloader' match='(osgi.serviceloader=org.slf4j.spi.SLF4JServiceProvider)'>
          <description>
            slf4j.api
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            slf4j.api
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='slf4j.api.source' range='[2.0.18,2.0.18]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='slf4j.api' version='2.0.18'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: slf4j.api&#xA;Bundle-Version: 2.0.18
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='slf4j.reload4j' version='2.0.18' singleton='false' generation='2'>
      <update id='slf4j.reload4j' range='[0.0.0,2.0.18)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='SLF4J Reload4j Provider'/>
        <property name='org.eclipse.equinox.p2.description' value='SLF4J Reload4j Provider'/>
        <property name='org.eclipse.equinox.p2.provider' value='SLF4J.ORG'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://reload4j.qos.ch'/>
        <property name='maven-groupId' value='org.slf4j'/>
        <property name='maven-artifactId' value='slf4j-reload4j'/>
        <property name='maven-version' value='2.0.18'/>
        <property name='maven-repository' value='eclipse.maven.central.mirror'/>
        <property name='maven-type' value='jar'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='slf4j.reload4j' version='2.0.18'/>
        <provided namespace='osgi.bundle' name='slf4j.reload4j' version='2.0.18'/>
        <provided namespace='java.package' name='org.slf4j.reload4j' version='2.0.18'>
          <properties size='1'>
            <property name='java.package.directive.uses' value='org.slf4j,org.slf4j.event,org.slf4j.helpers,org.slf4j.spi' type='List'/>
          </properties>
        </provided>
        <provided namespace='osgi.identity' name='slf4j.reload4j' version='2.0.18'>
          <properties size='1'>
            <property name='type' value='osgi.bundle'/>
          </properties>
        </provided>
        <provided namespace='osgi.service' name='slf4j.reload4j_2.0.18-1' version='0.0.0'>
          <properties size='2'>
            <property name='objectClass' value='org.slf4j.spi.SLF4JServiceProvider' type='List'/>
            <property name='type' value='reload4j'/>
          </properties>
        </provided>
        <provided namespace='osgi.serviceloader' name='org.slf4j.spi.SLF4JServiceProvider' version='0.0.0'>
          <properties size='1'>
            <property name='type' value='reload4j'/>
          </properties>
        </provided>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.apache.log4j' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.log4j.spi' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.slf4j' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.slf4j.event' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.slf4j.helpers' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.slf4j.spi' range='[2.0.0,3.0.0)'/>
        <requiredProperties namespace='osgi.extender' match='(&amp;(osgi.extender=osgi.serviceloader.registrar)(version&gt;=1.0.0)(!(version&gt;=2.0.0)))'>
          <description>
            slf4j.reload4j
          </description>
        </requiredProperties>
        <requiredProperties namespace='osgi.ee' match='(&amp;(osgi.ee=JavaSE)(version=1.8))'>
          <description>
            slf4j.reload4j
          </description>
        </requiredProperties>
        <required namespace='org.eclipse.equinox.p2.iu' name='slf4j.reload4j.source' range='[2.0.18,2.0.18]' optional='true'>
          <filter>
            (org.eclipse.update.install.sources=true)
          </filter>
        </required>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='slf4j.reload4j' version='2.0.18'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: slf4j.reload4j&#xA;Bundle-Version: 2.0.18
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcern.plcverif.cli.cmdline.app.product.application' version='1.0.0.202607171441'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.application' version='1.0.0.202607171441'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.executable.win32.win32.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.win32.win32.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.3.0.v20260203-2149,1.3.0.v20260203-2149]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.2.1500.v20250801-0854,1.2.1500.v20250801-0854]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.win32.win32.x86_64.plcverif-cli' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.7.100.v20251111-0406,1.7.100.v20251111-0406]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64.plcverif-cli' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
    </unit>
    <unit id='toolingcern.plcverif.cli.cmdline.app.product.config.gtk.linux.x86_64' version='1.0.0.202607171441' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.config.gtk.linux.x86_64' version='1.0.0.202607171441'/>
        <provided namespace='toolingcern.plcverif.cli.cmdline.app.product' name='cern.plcverif.cli.cmdline.app.product.config' version='1.0.0.202607171441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.product,propValue:cern.plcverif.cli.cmdline.app.cmdline);setProgramProperty(propName:eclipse.application,propValue:cern.plcverif.cli.cmdline.app.application);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:eclipse.application,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcern.plcverif.cli.cmdline.app.product.configuration' version='1.0.0.202607171441'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.configuration' version='1.0.0.202607171441'/>
      </provides>
      <requires size='16'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.ini.win32.win32.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.runtime' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.config.win32.win32.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.apache.felix.scr' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.event' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.config.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.ini.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.p2.reconciler.dropins' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins' range='[1.0.0.202607171441,1.0.0.202607171441]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
    </unit>
    <unit id='toolingcern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' range='[1.0.0.202607171441,1.0.0.202607171441]'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder}); chmod(targetDir:${installFolder}, targetFile:plcverif-cli, permissions:755);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcern.plcverif.cli.cmdline.app.product.ini.gtk.linux.x86_64' version='1.0.0.202607171441' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcern.plcverif.cli.cmdline.app.product.ini.gtk.linux.x86_64' version='1.0.0.202607171441'/>
        <provided namespace='toolingcern.plcverif.cli.cmdline.app.product' name='cern.plcverif.cli.cmdline.app.product.ini' version='1.0.0.202607171441'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            addJvmArg(jvmArg:-Xss5m);addJvmArg(jvmArg:-Dlog4j2.statusLoggerLevel=OFF);addJvmArg(jvmArg:--enable-native-access=ALL-UNNAMED);addJvmArg(jvmArg:--sun-misc-unsafe-memory-access=allow);
          </instruction>
          <instruction key='unconfigure'>
            removeJvmArg(jvmArg:-Xss5m);removeJvmArg(jvmArg:-Dlog4j2.statusLoggerLevel=OFF);removeJvmArg(jvmArg:--enable-native-access=ALL-UNNAMED);removeJvmArg(jvmArg:--sun-misc-unsafe-memory-access=allow);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.2.18'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.apache.felix.scr' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='2.2.18'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.200.v20251220-0953'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.34.200.v20251220-0953'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.20.400.v20260512-1534'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.20.400.v20260512-1534'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.7.300.v20250518-0609'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.7.300.v20250518-0609'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.p2.reconciler.dropins' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' range='1.5.800.v20251111-0852'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.p2.reconciler.dropins' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' range='1.5.800.v20251111-0852'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202607171441' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.5.700.v20251111-1031'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' version='1.0.0.202607171441'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolinggtk.linux.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.5.700.v20251111-1031'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.7.100.v20251111-0406' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.7.100.v20251111-0406'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.7.100.v20251111-0406'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.7.100.v20251111-0406'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.2.1500.v20250801-0854'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' version='1.2.1500.v20250801-0854'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='1.2.1500.v20250801-0854'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
      </filter>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='166'>
    <iuProperties id='cern.plcverif.cli.cmdline.app.product' version='1.0.0.202607171441'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='cern.plcverif.cli.cmdline.app.product.executable.gtk.linux.x86_64' version='1.0.0.202607171441'>
      <properties size='1'>
        <property name='unzipped|@artifact|C:\Main\Work\CERN\plcverif\cern.plcverif.cli\releng\cern.plcverif.cli.cmdline.product\target\products\cern.plcverif.cli.cmdline.app.product\linux\gtk\x86_64' value='C:\Main\Work\CERN\plcverif\cern.plcverif.cli\releng\cern.plcverif.cli.cmdline.product\target\products\cern.plcverif.cli.cmdline.app.product\linux\gtk\x86_64\plcverif-cli|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
